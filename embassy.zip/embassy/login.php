<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="POS - Bootstrap Admin Template">
    <meta name="keywords" content="admin, estimates, bootstrap, business, corporate, creative, invoice, html5, responsive, Projects">
    <meta name="author" content="Dreamguys - Bootstrap Admin Template">
    <meta name="robots" content="noindex, nofollow">
    <title>Login - Embassy Dashboard</title>

    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- IziToast CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
</head>
<body class="account-page">

<div class="main-wrapper">
    <div class="account-content">
        <div class="login-wrapper">
            <div class="login-content">
                <div class="login-userset">
                    <!-- <div class="login-logo">
                        <img src="assets/img/logo.png" alt="img">
                    </div> -->
                    <div class="login-userheading">
                        <h3>Sign In</h3>
                        <h4>Please login to your account</h4>
                    </div>
                    <form id="loginForm">
                        <div class="form-login">
                            <label>Email</label>
                            <div class="form-addons">
                                <input type="text" name="email" placeholder="Enter your email address" required>
                                <img src="assets/img/icons/mail.svg" alt="img">
                            </div>
                        </div>
                        <div class="form-login">
                            <label>Password</label>
                            <div class="pass-group">
                                <input type="password" name="password" class="pass-input" placeholder="Enter your password" required>
                                <span class="fas toggle-password fa-eye-slash"></span>
                            </div>
                        </div>
                        <!-- <div class="form-login">
                            <div class="alreadyuser">
                                <h4><a href="forgetpassword.html" class="hover-a">Forgot Password?</a></h4>
                            </div>
                        </div> -->
                        <div class="form-login">
                            <button type="submit" class="btn btn-login">Sign In</button>
                        </div>
                        <div class="signinform text-center">
                            <h4>Don’t have an account? <a href="sign-up.php" class="hover-a">Sign Up</a></h4>
                        </div>
                    </form>
                </div>
            </div>
            <div class="login-img">
                <img src="assets/img/login.jpg" alt="img">
            </div>
        </div>
    </div>
</div>

<!-- IziToast JS -->
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

<script src="assets/js/jquery-3.6.0.min.js"></script>
<script src="assets/js/feather.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>

<script>
$(document).ready(function() {
    $('#loginForm').on('submit', function(e) {
        e.preventDefault(); // Prevent default form submission

        // Get email and password values from input fields
        var email = $('input[name="email"]').val();
        var password = $('input[name="password"]').val();

        // Make sure both fields are filled
        if (email === "" || password === "") {
            iziToast.error({
                title: 'Error',
                message: 'Please fill in both fields.',
                backgroundColor: 'red',
                position: 'topRight'
            });
            return; // Stop execution
        }

        // AJAX request
        $.ajax({
            url: 'utilities/log-in.php',
            type: 'POST',
            data: { email: email, password: password }, // Pass email and password
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Redirect based on user role
                    if (response.role === 'admin') {
                        window.location.href = 'admin/index.php'; // Redirect to admin dashboard
                    } else if (response.role === 'student') {
                        window.location.href = 'student/index.php'; // Redirect to student dashboard
                    } else {
                        // Handle other roles if necessary
                        iziToast.info({
                            title: 'Info',
                            message: 'Role not recognized. Redirecting to the homepage.',
                            backgroundColor: 'blue',
                            position: 'topRight'
                        });
                        window.location.href = 'homepage.php'; // Example redirection for unhandled roles
                    }
                } else {
                    iziToast.error({
                        title: 'Error',
                        message: response.message,
                        backgroundColor: 'red',
                        position: 'topRight'
                    });
                }
            },
            error: function() {
                iziToast.error({
                    title: 'Error',
                    message: 'There was an issue with the request',
                    backgroundColor: 'red',
                    position: 'topRight'
                });
            }
        });
    });
});
</script>


</body>
</html>
