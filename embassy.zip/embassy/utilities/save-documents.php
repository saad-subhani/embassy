<?php
session_start(); // Start the session to get the user_id

include 'conn.php';

// Initialize an array for the response
$response = [
    'success' => false,
    'message' => ''
];

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Ensure the user is logged in by checking the session
        if (!isset($_SESSION['user_id'])) {
            throw new Exception('User not logged in');
        }
        $user_id = $_SESSION['user_id']; // Get user_id from session

        // Initialize an array to hold file paths
        $filePaths = [];

        // Define the upload directory
        $uploadDir = 'uploads/'; // Ensure this directory exists and is writable

        // Handle each file upload
        $files = [
            'visaApplication',
            'visaFeeReceipt',
            'passportCopy',
            'photo',
            'verificationDegree',
            'verificationTranscript'
        ];

        foreach ($files as $file) {
            // Check if the file was uploaded without errors
            if (isset($_FILES[$file]) && $_FILES[$file]['error'] == 0) {
                $fileName = basename($_FILES[$file]['name']);
                $targetFilePath = $uploadDir . $fileName;

                // Move the uploaded file to the designated directory
                if (move_uploaded_file($_FILES[$file]['tmp_name'], $targetFilePath)) {
                    $filePaths[$file] = $targetFilePath;
                } else {
                    throw new Exception("Error uploading $file.");
                }
            } else {
                throw new Exception("Error with file $file: " . $_FILES[$file]['error']);
            }
        }

        // Prepare and execute the SQL statement to save the file paths and user_id to the database
        $sql = "INSERT INTO uploaded_documents (visa_application, visa_fee_receipt, passport_copy, photo, verification_degree, verification_transcript, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "ssssssi",
            $filePaths['visaApplication'], 
            $filePaths['visaFeeReceipt'], 
            $filePaths['passportCopy'], 
            $filePaths['photo'], 
            $filePaths['verificationDegree'], 
            $filePaths['verificationTranscript'], 
            $user_id // Bind the user_id
        );

        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = "Documents uploaded successfully!";
        } else {
            throw new Exception("Error submitting data: " . $stmt->error);
        }

        // Close the statement
        $stmt->close();
    } catch (Exception $e) {
        $response['message'] = "Error: " . $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request method.";
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
