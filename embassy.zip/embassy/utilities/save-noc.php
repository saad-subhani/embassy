<?php 
session_start();
include 'conn.php'; // Include your database connection 

// Ensure the user is logged in by checking the session
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Error: User not logged in.']);
    exit; // Exit the script
}

$user_id = $_SESSION['user_id']; // Get user_id from session

// Function to handle file uploads
function handleFileUpload($inputName, $uploadDir) {
    if (isset($_FILES[$inputName])) {
        $files = $_FILES[$inputName];
        $filePaths = [];

        if (is_array($files['name'])) {
            foreach ($files['name'] as $key => $fileName) {
                if ($files['error'][$key] === UPLOAD_ERR_OK) {
                    $tmpName = $files['tmp_name'][$key];
                    $filePath = $uploadDir . basename($fileName);

                    // Move the uploaded file to the destination
                    if (move_uploaded_file($tmpName, $filePath)) {
                        $filePaths[] = $filePath;
                    }
                }
            }
        } else {
            // For single file uploads
            if ($files['error'] === UPLOAD_ERR_OK) {
                $tmpName = $files['tmp_name'];
                $filePath = $uploadDir . basename($files['name']);

                if (move_uploaded_file($tmpName, $filePath)) {
                    $filePaths[] = $filePath;
                }
            }
        }

        return !empty($filePaths) ? implode(',', $filePaths) : null;
    }
    return null;
}

// Directory to save the uploaded files
$uploadDir = 'uploads/noc_documents/'; // Ensure this directory exists and is writable

// Handle the uploads for different sections
$passportExtensionStudyVisa = handleFileUpload('extensionStudyVisaPassport', $uploadDir);
$visaExtensionStudyVisa = handleFileUpload('extensionStudyVisaLastVisa', $uploadDir);
$supportingDocsExtensionStudyVisa = handleFileUpload('extensionStudyVisaDocuments', $uploadDir);

$passportAccountOpening = handleFileUpload('accountOpeningPassport', $uploadDir);
$visaAccountOpening = handleFileUpload('accountOpeningVisa', $uploadDir);
$supportingDocsAccountOpening = handleFileUpload('accountOpeningDocuments', $uploadDir);

$certificateSchoolEquivalence = handleFileUpload('equivalenceCertificateSchool', $uploadDir);
$admissionLetterEquivalence = handleFileUpload('equivalenceCertificateAdmission', $uploadDir);
$supportingDocsEquivalence = handleFileUpload('equivalenceCertificateDocuments', $uploadDir);

$otherPurposesArabic = $_POST['otherPurposesArabic'] ?? null;
$supportingDocsOtherPurposes = handleFileUpload('otherPurposesDocuments', $uploadDir);

$degreeAuthorizedLetter = handleFileUpload('authorizedLetterDegree', $uploadDir);
$passportAuthorizedLetter = handleFileUpload('authorizedLetterPassport', $uploadDir);
$authorizedPersonID = handleFileUpload('authorizedPersonID', $uploadDir);
$supportingDocsAuthorizedLetter = handleFileUpload('authorizedLetterDocuments', $uploadDir);

// Insert into database including user_id
$sql = "INSERT INTO noc_documents (
    passport_extension_study_visa, last_visa_extension_study_visa, supporting_docs_extension_study_visa,
    passport_account_opening, last_visa_account_opening, supporting_docs_account_opening,
    certificate_school_equivalence, admission_letter_equivalence, supporting_docs_equivalence,
    other_purposes_arabic, supporting_docs_other_purposes,
    degree_authorized_letter, passport_authorized_letter, authorized_person_id, supporting_docs_authorized_letter,
    user_id
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param('sssssssssssssssi', 
    $passportExtensionStudyVisa, $visaExtensionStudyVisa, $supportingDocsExtensionStudyVisa,
    $passportAccountOpening, $visaAccountOpening, $supportingDocsAccountOpening,
    $certificateSchoolEquivalence, $admissionLetterEquivalence, $supportingDocsEquivalence,
    $otherPurposesArabic, $supportingDocsOtherPurposes,
    $degreeAuthorizedLetter, $passportAuthorizedLetter, $authorizedPersonID, $supportingDocsAuthorizedLetter,
    $user_id // Bind the user_id
);

// Prepare the response
$response = [];

if ($stmt->execute()) {
    $response['success'] = true;
    $response['message'] = "Files uploaded and data saved successfully.";
} else {
    $response['success'] = false;
    $response['message'] = "Error: " . $stmt->error;
}

// Return the JSON response
echo json_encode($response);
?>
