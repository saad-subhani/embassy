<?php
include 'conn.php';

// Pagination setup
$limit = 10; // Number of entries per page
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Get the status from the query parameters
$status = isset($_GET['status']) ? $_GET['status'] : 'all';

// Build the SQL query based on the status filter
$sql = "SELECT id, full_name, dob, address_palestine, number, Email, university_name, major, visa_expire_date, status FROM user_information";

// Modify the query to filter by status if it's not 'all'
if ($status !== 'all') {
    $sql .= " WHERE status = '" . $conn->real_escape_string($status) . "'";
}

$sql .= " LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

// Output the table rows
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Your existing row rendering logic here...
        $badgeColor = match ($row['status']) {
            'Pending' => 'badge-warning',
            'Rejected' => 'badge-danger',
            'Approved' => 'badge-success',
            default => 'badge-secondary',
        };

        echo "<tr>
            <td><label class='checkboxs'><input type='checkbox'><span class='checkmarks'></span></label></td>
            <td class='productimgname'>
                <a href='javascript:void(0);'>" . htmlspecialchars($row['full_name']) . "</a>
            </td>
            <td>" . htmlspecialchars($row['dob']) . "</td>
            <td>" . htmlspecialchars($row['address_palestine']) . "</td>
            <td>
                <a href='https://wa.me/" . htmlspecialchars($row['number']) . "' target='_blank'>" . htmlspecialchars($row['number']) . "</a><br>
                <a href='mailto:" . htmlspecialchars($row['Email']) . "'>" . htmlspecialchars($row['Email']) . "</a>
            </td>
            <td>" . htmlspecialchars($row['university_name']) . "</td>
            <td>" . htmlspecialchars($row['major']) . "</td>
            <td>" . htmlspecialchars($row['visa_expire_date']) . "</td>
            <td><span class='badge $badgeColor'>" . htmlspecialchars($row['status']) . "</span></td>
            <td>
                <a class='me-3' href='student-detail.php?id=" . htmlspecialchars($row['id']) . "'>
                    <img src='../assets/img/icons/eye.svg' alt='img'>
                </a>
                <div class='dropdown d-inline-block'>
                    <a class='me-3 edit-status' href='javascript:void(0);' data-id='" . htmlspecialchars($row['id']) . "' data-status='" . htmlspecialchars($row['status']) . "' data-bs-toggle='dropdown' aria-expanded='false'>
                        <img src='../assets/img/icons/edit.svg' alt='img'>
                    </a>
                    <ul class='dropdown-menu'></ul>
                </div>
                <a class='confirm-text' href='javascript:void(0);'>
                    <img src='../assets/img/icons/delete.svg' alt='img'>
                </a>
            </td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='10'>No records found</td></tr>";
}

$conn->close();
?>
