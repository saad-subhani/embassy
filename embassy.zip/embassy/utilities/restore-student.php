<?php
// Include your database connection file
include 'conn.php'; // Adjust the path as necessary

// Set the header to indicate JSON response
header('Content-Type: application/json');

// Get the raw POST data (which in this case is expected to be JSON)
$rawData = file_get_contents('php://input');

// Decode the JSON data into a PHP associative array
$data = json_decode($rawData, true);

// Check if the 'id' parameter is present in the JSON input
if (isset($data['id'])) {
    $id = $data['id'];

    // Prepare the SQL query to update the status to 'Pending'
    $sql = "UPDATE user_information SET status = 'Pending' WHERE id = ?";

    // Initialize the prepared statement
    if ($stmt = $conn->prepare($sql)) {
        // Bind the 'id' parameter to the SQL query
        $stmt->bind_param('i', $id); // 'i' specifies that the parameter is an integer

        // Execute the query
        if ($stmt->execute()) {
            // Check if any rows were affected (i.e., if the record was found and updated)
            if ($stmt->affected_rows > 0) {
                // Respond with a success message in JSON format
                echo json_encode(['success' => true, 'message' => 'Record successfully restored to Pending status.']);
            } else {
                // Respond with an error if no rows were updated (e.g., invalid id or already in Pending status)
                echo json_encode(['success' => false, 'message' => 'Record not found or already in Pending status.']);
            }
        } else {
            // Respond with an error message if the query failed
            echo json_encode(['success' => false, 'message' => 'Failed to restore the record.']);
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        // Respond with an error if the SQL query couldn't be prepared
        echo json_encode(['success' => false, 'message' => 'Error preparing SQL statement.']);
    }
} else {
    // Respond with an error if the 'id' is not provided in the JSON request
    echo json_encode(['success' => false, 'message' => 'Invalid request. No ID provided.']);
}

// Close the database connection
$conn->close();
?>
