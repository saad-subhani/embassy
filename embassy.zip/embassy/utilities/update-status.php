<?php
include 'conn.php';

// Get the JSON data
$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['id']) && isset($data['status'])) {
    $id = $data['id'];
    $status = $data['status'];

    // Prepare the SQL statement to update both status and status_change_date
    $stmt = $conn->prepare("UPDATE user_information SET status = ?, status_change_date = NOW() WHERE id = ?");
    $stmt->bind_param("si", $status, $id);

    // Execute the statement and check for success
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Status updated successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update status.']);
    }

    // Close the statement
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid input.']);
}

// Close the database connection
$conn->close();
?>
