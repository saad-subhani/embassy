<?php
session_start(); // Start the session

header('Content-Type: application/json');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Include database connection
    include 'conn.php';

    try {
        // Collect form data
        $title = isset($_POST['title']) ? $_POST['title'] : '';
        $application_for = isset($_POST['application_for']) ? $_POST['application_for'] : '';
        $content = isset($_POST['content']) ? $_POST['content'] : '';

        // Get user ID from session
        if (!isset($_SESSION['user_id'])) {
            throw new Exception('User not logged in');
        }
        $user_id = $_SESSION['user_id'];

        // Validate required fields
        if (empty($title) || empty($application_for) || empty($content)) {
            throw new Exception('All fields are required');
        }

        // Handle file upload if an image is provided
        $targetDir = "uploads/applications/";
        $fileName = '';

        if (!empty($_FILES['image']['name'])) {
            $fileName = basename($_FILES['image']['name']);
            $targetFilePath = $targetDir . $fileName; // Ensure a slash before the file name
            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

            // Allow certain file formats
            $allowedTypes = ['jpg', 'png', 'jpeg', 'gif'];
            if (!in_array(strtolower($fileType), $allowedTypes)) {
                throw new Exception('Invalid file type');
            }

            // Upload file to the server
            if (!move_uploaded_file($_FILES['image']['tmp_name'], $targetFilePath)) {
                throw new Exception('File upload failed');
            }
        }

        // Insert data into the database
        $sql = "INSERT INTO applications (title, application_for, content, image, user_id) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        
        if (!$stmt) {
            throw new Exception('Error preparing statement');
        }

        $stmt->bind_param("ssssi", $title, $application_for, $content, $fileName, $user_id);

        if (!$stmt->execute()) {
            throw new Exception('Database error: ' . $stmt->error);
        }

        // Success response
        echo json_encode(['success' => true, 'message' => 'Application submitted successfully']);
        
    } catch (Exception $e) {
        // Error response
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    } finally {
        // Close database connection
        if (isset($stmt)) {
            $stmt->close();
        }
        $conn->close();
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>
