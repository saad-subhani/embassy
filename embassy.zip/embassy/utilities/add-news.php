<?php
header('Content-Type: application/json');

// Include database connection
include 'conn.php';

$response = ['success' => false, 'message' => '']; // Initialize response array

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];

    // Directory where the image will be saved
    $targetDir = "uploads/news/";
    $imageName = basename($_FILES['image']['name']);
    $targetFile = $targetDir . $imageName;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if image is valid
    $check = getimagesize($_FILES['image']['tmp_name']);
    if ($check !== false) {
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($imageFileType, $allowedTypes)) {
            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                // Insert into database
                $query = "INSERT INTO news (title, content, image_path) VALUES (?, ?, ?)";
                if ($stmt = $conn->prepare($query)) {
                    $stmt->bind_param("sss", $title, $content, $targetFile);

                    if ($stmt->execute()) {
                        $response['success'] = true;
                        $response['message'] = "The title, content, and image have been uploaded successfully.";
                    } else {
                        $response['message'] = "Error: " . $stmt->error;
                    }

                    $stmt->close();
                } else {
                    $response['message'] = "Error preparing statement: " . $conn->error;
                }
            } else {
                $response['message'] = "Error uploading the file.";
            }
        } else {
            $response['message'] = "Only JPG, JPEG, PNG, and GIF files are allowed.";
        }
    } else {
        $response['message'] = "The file is not a valid image.";
    }
} else {
    $response['message'] = "Invalid request.";
}

// Return response
echo json_encode($response);

// Close connection
$conn->close();
?>
