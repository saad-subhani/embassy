<?php
include 'conn.php';

// Function to upload files
function uploadFile($fileInputName) {
    global $targetDir;
    $targetFile = $targetDir . basename($_FILES[$fileInputName]["name"]);
    if (move_uploaded_file($_FILES[$fileInputName]["tmp_name"], $targetFile)) {
        return $targetFile; // Return the file path if uploaded successfully
    }
    return null; // Return null if upload failed
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize inputs
    $fullName = htmlspecialchars($_POST['fullName']);
    $fatherName = htmlspecialchars($_POST['fatherName']);
    $dob = htmlspecialchars($_POST['dob']);
    $gender = htmlspecialchars($_POST['gender']);
    $cnic = htmlspecialchars($_POST['cnic']);
    $phone = htmlspecialchars($_POST['phone']);
    $email = htmlspecialchars($_POST['email']);
    $alternatePhone = htmlspecialchars($_POST['alternatePhone']);

    // Retrieve additional form inputs
    $addressPalestine = $conn->real_escape_string($_POST['addressPalestine']);
    $addressPakistan = $conn->real_escape_string($_POST['addressPakistan']);
    $universityName = $conn->real_escape_string($_POST['universityName']);
    $major = $conn->real_escape_string($_POST['major']);
    $studentId = $conn->real_escape_string($_POST['studentId']);
    $visaStartDate = $_POST['visaStartDate'];
    $visaExpireDate = $_POST['visaExpireDate'];

    // Handle file uploads
    $targetDir = 'uploads/'; // Directory for file uploads
    $files = [
        'visaApplication',
        'visaFeeReceipt',
        'passportCopy',
        'photo',
        'extensionStudyVisaPassport',
        'extensionStudyVisaLastVisa',
        'accountOpeningPassport',
        'accountOpeningVisa',
        'equivalenceCertificateSchool',
        'equivalenceCertificateAdmission',
        'verificationDegree',
        'verificationTranscript',
        'authorizedLetterDegree',
        'authorizedLetterPassport',
        'authorizedPersonID'
    ];
    $filePaths = [];

    foreach ($files as $file) {
        if (isset($_FILES[$file]) && $_FILES[$file]['error'] === UPLOAD_ERR_OK) {
            $fileTmpPath = $_FILES[$file]['tmp_name'];
            $fileName = $_FILES[$file]['name'];
            $filePath = $targetDir . basename($fileName);

            // Move the file to the uploads directory
            if (move_uploaded_file($fileTmpPath, $filePath)) {
                $filePaths[$file] = $filePath;
            } else {
                echo "Error uploading file: $fileName";
                exit;
            }
        } else {
            echo "Error with file: $file";
            exit;
        }
    }

    // Prepare SQL statement to insert data into the database
    $sql = "INSERT INTO student_details (fullName, fatherName, dob, gender, cnic, phone, email, alternatePhone, address_palestine, address_pakistan, university_name, major, student_id, visa_start_date, visa_expire_date, visa_application, visa_fee_receipt, passport_copy, photo, extension_study_visa_passport, extension_study_visa_last_visa, accountOpeningPassport, accountOpeningVisa, equivalenceCertificateSchool, equivalenceCertificateAdmission, verificationDegree, verificationTranscript, degree_path, passport_path, authorized_id_path, comments)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare and bind
    $stmt = $conn->prepare($sql);
    $degreePath = $passportPath = $authorizedIDPath = $comments = '';

    // Upload additional files if present
    $comments = htmlspecialchars($_POST['comments']);

    // Insert the file paths for specific fields
    if (isset($filePaths['authorizedLetterDegree'])) {
        $degreePath = $filePaths['authorizedLetterDegree'];
    }
    if (isset($filePaths['authorizedLetterPassport'])) {
        $passportPath = $filePaths['authorizedLetterPassport'];
    }
    if (isset($filePaths['authorizedPersonID'])) {
        $authorizedIDPath = $filePaths['authorizedPersonID'];
    }

    // Bind parameters
    $stmt->bind_param(
        "ssssssssssssssssssssssssssssssss",
        $fullName,
        $fatherName,
        $dob,
        $gender,
        $cnic,
        $phone,
        $email,
        $alternatePhone,
        $addressPalestine,
        $addressPakistan,
        $universityName,
        $major,
        $studentId,
        $visaStartDate,
        $visaExpireDate,
        $filePaths['visaApplication'],
        $filePaths['visaFeeReceipt'],
        $filePaths['passportCopy'],
        $filePaths['photo'],
        $filePaths['extensionStudyVisaPassport'],
        $filePaths['extensionStudyVisaLastVisa'],
        $filePaths['accountOpeningPassport'],
        $filePaths['accountOpeningVisa'],
        $filePaths['equivalenceCertificateSchool'],
        $filePaths['equivalenceCertificateAdmission'],
        $filePaths['verificationDegree'],
        $filePaths['verificationTranscript'],
        $degreePath,
        $passportPath,
        $authorizedIDPath,
        $comments
    );

    // Execute the statement
    if ($stmt->execute()) {
        echo "Records inserted successfully.";
    } else {
        echo "Error inserting records: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
