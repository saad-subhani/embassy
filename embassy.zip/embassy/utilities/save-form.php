<?php
session_start(); // Start the session to get the user_id

include 'conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Check if the user is logged in by validating user_id from session
        if (!isset($_SESSION['user_id'])) {
            throw new Exception('User not logged in');
        }
        $user_id = $_SESSION['user_id']; // Get user_id from session
        
        // Sanitize and prepare form data
        $full_name = $conn->real_escape_string(htmlspecialchars($_POST['fullName']));
        $father_name = $conn->real_escape_string(htmlspecialchars($_POST['fatherName']));
        $dob = $conn->real_escape_string($_POST['dob']);
        $address_palestine = $conn->real_escape_string(htmlspecialchars($_POST['addressPalestine']));
        $address_pakistan = $conn->real_escape_string(htmlspecialchars($_POST['addressPakistan']));
        $university_name = $conn->real_escape_string(htmlspecialchars($_POST['universityName']));
        $major = $conn->real_escape_string(htmlspecialchars($_POST['major']));
        $student_id = $conn->real_escape_string(htmlspecialchars($_POST['studentId']));
        $visa_start_date = $conn->real_escape_string($_POST['visaStartDate']);
        $visa_expire_date = $conn->real_escape_string($_POST['visaExpireDate']);
        $email = $conn->real_escape_string(htmlspecialchars($_POST['email']));
        $contact_number = $conn->real_escape_string(htmlspecialchars($_POST['contactNumber']));

        // File upload handling for personal picture
        $upload_dir = 'uploads/'; // Define the upload directory
        $personal_picture = $_FILES['personalPicture'];
        $picture_name = $personal_picture['name'];
        $picture_tmp_name = $personal_picture['tmp_name'];
        $picture_error = $personal_picture['error'];

        // Validate the uploaded file
        $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');
        $picture_extension = strtolower(pathinfo($picture_name, PATHINFO_EXTENSION));

        if ($picture_error === 0) {
            if (in_array($picture_extension, $allowed_extensions)) {
                // Set a unique name for the file to avoid conflicts
                $new_picture_name = uniqid('', true) . '.' . $picture_extension;
                $picture_destination = $upload_dir . $new_picture_name;

                // Move the uploaded file to the target directory
                if (move_uploaded_file($picture_tmp_name, $picture_destination)) {
                    // Prepare and execute the SQL statement with user_id, email, and contact number
                    $sql = "INSERT INTO user_information (full_name, father_name, dob, address_palestine, address_pakistan, university_name, major, student_id, visa_start_date, visa_expire_date, email, number, personal_picture, user_id) VALUES ('$full_name', '$father_name', '$dob', '$address_palestine', '$address_pakistan', '$university_name', '$major', '$student_id', '$visa_start_date', '$visa_expire_date', '$email', '$contact_number', '$new_picture_name', '$user_id')";

                    if ($conn->query($sql) === TRUE) {
                        echo "Data submitted successfully!";
                    } else {
                        throw new Exception("Error submitting data: " . $conn->error);
                    }
                } else {
                    throw new Exception("Error moving the uploaded file.");
                }
            } else {
                throw new Exception("Invalid file type. Only JPG, JPEG, PNG, and GIF files are allowed.");
            }
        } else {
            throw new Exception("Error uploading the picture. Error code: " . $picture_error);
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid request method.";
}
?>
<?php

include 'conn.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Ensure the user is logged in by checking the session
        if (!isset($_SESSION['user_id'])) {
            throw new Exception('User not logged in');
        }
        $user_id = $_SESSION['user_id']; // Get user_id from session

        // Initialize an array to hold file paths
        $filePaths = [];

        // Define the upload directory
        $uploadDir = 'uploads/'; // Ensure this directory exists and is writable

        // Handle each file upload
        $files = [
            'visaApplication',
            'visaFeeReceipt',
            'passportCopy',
            'photo',
            'verificationDegree',
            'verificationTranscript'
        ];

        foreach ($files as $file) {
            // Check if the file was uploaded without errors
            if (isset($_FILES[$file]) && $_FILES[$file]['error'] == 0) {
                $fileName = basename($_FILES[$file]['name']);
                $targetFilePath = $uploadDir . $fileName;

                // Move the uploaded file to the designated directory
                if (move_uploaded_file($_FILES[$file]['tmp_name'], $targetFilePath)) {
                    $filePaths[$file] = $targetFilePath;
                } else {
                    throw new Exception("Error uploading $file.");
                }
            } else {
                throw new Exception("Error with file $file: " . $_FILES[$file]['error']);
            }
        }

        // Prepare and execute the SQL statement to save the file paths and user_id to the database
        $sql = "INSERT INTO uploaded_documents (visa_application, visa_fee_receipt, passport_copy, photo, verification_degree, verification_transcript, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "ssssssi",
            $filePaths['visaApplication'], 
            $filePaths['visaFeeReceipt'], 
            $filePaths['passportCopy'], 
            $filePaths['photo'], 
            $filePaths['verificationDegree'], 
            $filePaths['verificationTranscript'], 
            $user_id // Bind the user_id
        );

        if ($stmt->execute()) {
            echo "Documents uploaded successfully!";
        } else {
            throw new Exception("Error submitting data: " . $stmt->error);
        }

        // Close the statement
        $stmt->close();
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid request method.";
}
?>

<?php 

include 'conn.php'; // Include your database connection

// Ensure the user is logged in by checking the session
if (!isset($_SESSION['user_id'])) {
    die("Error: User not logged in.");
}

$user_id = $_SESSION['user_id']; // Get user_id from session

// Function to handle file uploads
function handleFileUpload($inputName, $uploadDir) {
    if (isset($_FILES[$inputName])) {
        $files = $_FILES[$inputName];
        $filePaths = [];

        if (is_array($files['name'])) {
            foreach ($files['name'] as $key => $fileName) {
                if ($files['error'][$key] === UPLOAD_ERR_OK) {
                    $tmpName = $files['tmp_name'][$key];
                    $filePath = $uploadDir . basename($fileName);

                    // Move the uploaded file to the destination
                    if (move_uploaded_file($tmpName, $filePath)) {
                        $filePaths[] = $filePath;
                    }
                }
            }
        } else {
            // For single file uploads
            if ($files['error'] === UPLOAD_ERR_OK) {
                $tmpName = $files['tmp_name'];
                $filePath = $uploadDir . basename($files['name']);

                if (move_uploaded_file($tmpName, $filePath)) {
                    $filePaths[] = $filePath;
                }
            }
        }

        return !empty($filePaths) ? implode(',', $filePaths) : null;
    }
    return null;
}

// Directory to save the uploaded files
$uploadDir = 'uploads/noc_documents/'; // Ensure this directory exists and is writable

// Handle the uploads for different sections
$passportExtensionStudyVisa = handleFileUpload('extensionStudyVisaPassport', $uploadDir);
$visaExtensionStudyVisa = handleFileUpload('extensionStudyVisaLastVisa', $uploadDir);
$supportingDocsExtensionStudyVisa = handleFileUpload('extensionStudyVisaDocuments', $uploadDir);

$passportAccountOpening = handleFileUpload('accountOpeningPassport', $uploadDir);
$visaAccountOpening = handleFileUpload('accountOpeningVisa', $uploadDir);
$supportingDocsAccountOpening = handleFileUpload('accountOpeningDocuments', $uploadDir);

$certificateSchoolEquivalence = handleFileUpload('equivalenceCertificateSchool', $uploadDir);
$admissionLetterEquivalence = handleFileUpload('equivalenceCertificateAdmission', $uploadDir);
$supportingDocsEquivalence = handleFileUpload('equivalenceCertificateDocuments', $uploadDir);

$otherPurposesArabic = $_POST['otherPurposesArabic'] ?? null;
$supportingDocsOtherPurposes = handleFileUpload('otherPurposesDocuments', $uploadDir);

$degreeAuthorizedLetter = handleFileUpload('authorizedLetterDegree', $uploadDir);
$passportAuthorizedLetter = handleFileUpload('authorizedLetterPassport', $uploadDir);
$authorizedPersonID = handleFileUpload('authorizedPersonID', $uploadDir);
$supportingDocsAuthorizedLetter = handleFileUpload('authorizedLetterDocuments', $uploadDir);

// Insert into database including user_id
$sql = "INSERT INTO noc_documents (
    passport_extension_study_visa, last_visa_extension_study_visa, supporting_docs_extension_study_visa,
    passport_account_opening, last_visa_account_opening, supporting_docs_account_opening,
    certificate_school_equivalence, admission_letter_equivalence, supporting_docs_equivalence,
    other_purposes_arabic, supporting_docs_other_purposes,
    degree_authorized_letter, passport_authorized_letter, authorized_person_id, supporting_docs_authorized_letter,
    user_id
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param('sssssssssssssssi', 
    $passportExtensionStudyVisa, $visaExtensionStudyVisa, $supportingDocsExtensionStudyVisa,
    $passportAccountOpening, $visaAccountOpening, $supportingDocsAccountOpening,
    $certificateSchoolEquivalence, $admissionLetterEquivalence, $supportingDocsEquivalence,
    $otherPurposesArabic, $supportingDocsOtherPurposes,
    $degreeAuthorizedLetter, $passportAuthorizedLetter, $authorizedPersonID, $supportingDocsAuthorizedLetter,
    $user_id // Bind the user_id
);

if ($stmt->execute()) {
    echo "Files uploaded and data saved successfully.";
} else {
    echo "Error: " . $stmt->error;
}
?>
