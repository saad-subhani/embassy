<?php
session_start(); // Start the session to get the user_id

include 'conn.php';

header('Content-Type: application/json'); // Set the header to return JSON

$response = ['success' => false, 'message' => '']; // Initialize response array

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Check if the user is logged in by validating user_id from session
        if (!isset($_SESSION['user_id'])) {
            throw new Exception('User not logged in');
        }
        $user_id = $_SESSION['user_id']; // Get user_id from session
        
        // Sanitize and prepare form data
        $full_name = $conn->real_escape_string(htmlspecialchars($_POST['fullName']));
        $father_name = $conn->real_escape_string(htmlspecialchars($_POST['fatherName']));
        $dob = $conn->real_escape_string($_POST['dob']);
        $address_palestine = $conn->real_escape_string(htmlspecialchars($_POST['addressPalestine']));
        $address_pakistan = $conn->real_escape_string(htmlspecialchars($_POST['addressPakistan']));
        $university_name = $conn->real_escape_string(htmlspecialchars($_POST['universityName']));
        $major = $conn->real_escape_string(htmlspecialchars($_POST['major']));
        $student_id = $conn->real_escape_string(htmlspecialchars($_POST['studentId']));
        $visa_start_date = $conn->real_escape_string($_POST['visaStartDate']);
        $visa_expire_date = $conn->real_escape_string($_POST['visaExpireDate']);
        $email = $conn->real_escape_string(htmlspecialchars($_POST['email']));
        $contact_number = $conn->real_escape_string(htmlspecialchars($_POST['contactNumber']));

        // File upload handling for personal picture
        $upload_dir = 'uploads/'; // Define the upload directory
        $personal_picture = $_FILES['personalPicture'];
        $picture_name = $personal_picture['name'];
        $picture_tmp_name = $personal_picture['tmp_name'];
        $picture_error = $personal_picture['error'];

        // Validate the uploaded file
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        $picture_extension = strtolower(pathinfo($picture_name, PATHINFO_EXTENSION));

        if ($picture_error === 0) {
            if (in_array($picture_extension, $allowed_extensions)) {
                // Set a unique name for the file to avoid conflicts
                $new_picture_name = uniqid('', true) . '.' . $picture_extension;
                $picture_destination = $upload_dir . $new_picture_name;

                // Move the uploaded file to the target directory
                if (move_uploaded_file($picture_tmp_name, $picture_destination)) {
                    // Prepare and execute the SQL statement with user_id, email, and contact number
                    $sql = "INSERT INTO user_information (full_name, father_name, dob, address_palestine, address_pakistan, university_name, major, student_id, visa_start_date, visa_expire_date, email, number, personal_picture, user_id) VALUES ('$full_name', '$father_name', '$dob', '$address_palestine', '$address_pakistan', '$university_name', '$major', '$student_id', '$visa_start_date', '$visa_expire_date', '$email', '$contact_number', '$new_picture_name', '$user_id')";

                    if ($conn->query($sql) === TRUE) {
                        $response['success'] = true; // Set success to true
                        $response['message'] = "Data submitted successfully!";
                    } else {
                        throw new Exception("Error submitting data: " . $conn->error);
                    }
                } else {
                    throw new Exception("Error moving the uploaded file.");
                }
            } else {
                throw new Exception("Invalid file type. Only JPG, JPEG, PNG, and GIF files are allowed.");
            }
        } else {
            throw new Exception("Error uploading the picture. Error code: " . $picture_error);
        }
    } catch (Exception $e) {
        $response['message'] = "Error: " . $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request method.";
}

echo json_encode($response); // Return the JSON response
?>
