<?php include 'inc/sidebar.php'; ?>

<div class="page-wrapper pagehead">
  <div class="content">

    <!-- Bootstrap card -->
    <div class="card">
      <div class="card-header">
        <h1 class="card-title">Add News</h1>
      </div>
      <div class="card-body">
        <!-- Form with title, image input, and CKEditor -->
        <form id="newsForm" enctype="multipart/form-data">
          <!-- Title input field on top -->
          <div class="mb-3">
            <label for="title" class="form-label">Title</label>
            <input type="text" name="title" id="title" class="form-control" placeholder="Enter title" required>
          </div>

          <!-- Image input field -->
          <div class="mb-3">
            <label for="imageUpload" class="form-label">Upload an image</label>
            <input type="file" name="image" id="imageUpload" class="form-control" accept="image/*">
          </div>
          
          <!-- CKEditor field -->
          <div class="mb-3">
            <label for="editor" class="form-label">Enter your content</label>
            <textarea name="content" id="editor" class="form-control" rows="5"></textarea>
          </div>
          
          <!-- Submit button with yellow background -->
          <button type="submit" class="btn btn-warning">Submit</button>
        </form>
      </div>
    </div>

  </div>
</div>

<!-- Include Bootstrap 5 -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Include CKEditor -->
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>

<!-- Include SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  // Initialize CKEditor
  CKEDITOR.replace('editor');

  // Handle form submission using AJAX
  document.getElementById('newsForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Prevent default form submission

    // Create a FormData object to handle file upload and form data
    var formData = new FormData(this);
    formData.append('content', CKEDITOR.instances['editor'].getData()); // Add CKEditor data

    // Send the AJAX request
    fetch('../utilities/add-news.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.json())
    .then(data => {
      // Handle the response
      if (data.success) {
        // Display SweetAlert on success
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: data.message,
          confirmButtonText: 'OK'
        });
      } else {
        // Display SweetAlert on error
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: data.message,
          confirmButtonText: 'OK'
        });
      }
    })
    .catch(error => {
      // Handle error
      console.error('Error:', error);
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'There was an error processing your request.',
        confirmButtonText: 'OK'
      });
    });
  });
</script>

<?php include 'inc/footer.php'; ?>
