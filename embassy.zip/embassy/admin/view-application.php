<?php include 'inc/sidebar.php'; ?>

<div class="page-wrapper">
    <div class="content">
        <?php
        include '../utilities/conn.php';

        // Get the application ID from the URL
        $id = $_GET['id'];

        // SQL query to fetch application details based on the ID
        $sql = "SELECT id, title, application_for, content FROM applications WHERE id = ?";
        $stmt = $conn->prepare($sql);
        
        // Check if the statement preparation was successful
        if ($stmt === false) {
            die("Error preparing statement: " . $conn->error);
        }

        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the application exists
        if ($result->num_rows > 0) {
            $application = $result->fetch_assoc();
        } else {
            // Handle case where application is not found
            echo "<h2>Application not found!</h2>";
            exit;
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
        ?>

        <style>
            @media print {
                body {
                    -webkit-print-color-adjust: exact; /* Preserve colors */
                }
                .no-print {
                    display: none; /* Hide elements with this class when printing */
                }
                .printable-card {
                    display: block; /* Ensure the card is displayed */
                }
                .card {
                    margin: 0; /* Remove margin for print */
                    box-shadow: none; /* Remove shadow for print */
                }
            }
            .card {
                margin: 20px auto; /* Center the card */
                padding: 20px;
                max-width: 600px; /* Set max width for the card */
                box-shadow: 0 2px 10px rgba(0,0,0,0.1); /* Optional: Add shadow for better appearance */
            }
            .card-title {
                font-size: 1.5rem;
                margin-bottom: 1rem;
            }
            .card-text {
                font-size: 1rem;
            }
        </style>

        <div class="container mt-5">
            <div class="card printable-card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($application['title']); ?></h5>
                    <p><strong>Application For:</strong> <?php echo htmlspecialchars($application['application_for']); ?></p>
                    <p><strong>Content:</strong> <?php echo $application['content']; ?></p>
                </div>
            </div>
            <div class="no-print text-center">
                <button onclick="window.print()" class="btn btn-primary">Print Application</button>
                <a href="all-applications.php" class="btn btn-secondary">Back to Applications</a>
                <button id="downloadBtn" class="btn btn-success">Download Application</button>
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <!-- Include jsPDF -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>

        <script>
            document.getElementById('downloadBtn').onclick = function() {
                // Import jsPDF
                const { jsPDF } = window.jspdf;

                // Create a new instance of jsPDF
                const doc = new jsPDF();

                // Use PHP to safely echo variables
                var title = "<?php echo addslashes(htmlspecialchars($application['title'])); ?>";
                var applicationFor = "<?php echo addslashes(htmlspecialchars($application['application_for'])); ?>";
                var content = "<?php echo addslashes(htmlspecialchars($application['content'])); ?>";

                // Add title
                doc.setFontSize(18);
                doc.text(title, 10, 10);
                
                // Add "Application For"
                doc.setFontSize(14);
                doc.text('Application For: ' + applicationFor, 10, 20);
                
                // Add content
                doc.setFontSize(12);
                doc.text('Content:', 10, 30);
                doc.text(content, 10, 40); // Adjust position if necessary

                // Save the PDF
                doc.save(title + '.pdf'); // Set the filename to the application title
            };
        </script>

    </div>
</div>

<?php include 'inc/footer.php'; ?>
