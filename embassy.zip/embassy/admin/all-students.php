<?php
include 'inc/sidebar.php';
include '../utilities/conn.php';

// Pagination setup
$limit = 10; // Number of entries per page
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Fetch total number of entries
$total_result = $conn->query("SELECT COUNT(*) AS total FROM user_information");
$total_rows = $total_result->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $limit);

// Fetch limited data for the current page
$sql = "SELECT id, full_name, dob, address_palestine, number, Email, university_name, major, visa_expire_date, status 
        FROM user_information 
        WHERE status IN ('Rejected', 'Approved', 'Pending') 
        LIMIT $limit OFFSET $offset";

$result = $conn->query($sql);
?>

<style>
    .custom-badge {
        display: inline-block;
        padding: 0.5em 0.75em;
        font-size: 0.75rem;
        font-weight: 700;
        color: #fff;
        border-radius: 0.25rem;
    }
    .badge-warning { background-color: #e0a800; }
    .badge-danger { background-color: #dc3545; }
    .badge-success { background-color: #28a745; }
    .badge-secondary { background-color: #6c757d; }
</style>

<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>Students Documentation</h4>
                <h6>Manage all Students</h6>
            </div>
            <div class="row mb-3">
    <div class="col-md-6 d-flex align-items-center">
        <label for="status-filter" class="me-3">Filter By:</label>
        <select id="status-filter" class="form-select" aria-label="Filter by status">
            <option value="all">All</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
        </select>
    </div>
    <div class="col-md-6 text-md-end">
        <a href="student-form.php" class="btn btn-added">
            <img src="../assets/img/icons/plus.svg" alt="img" class="me-1">Add New Student
        </a>
    </div>
</div>

        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th><label class="checkboxs"><input type="checkbox" id="select-all"><span class="checkmarks"></span></label></th>
                                <th>Full Name</th>
                                <th>Date of Birth</th>
                                <th>Address (Palestine)</th>
                                <th>Contact Info</th>
                                <th>University Name</th>
                                <th>Major</th>
                                <th>Visa Expiry Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="refresh">
                            <?php
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $badgeColor = match ($row['status']) {
                                        'Pending' => 'badge-warning',
                                        'Rejected' => 'badge-danger',
                                        'Approved' => 'badge-success',
                                        default => 'badge-secondary',
                                    };

                                    echo "<tr>
                                        <td><label class='checkboxs'><input type='checkbox'><span class='checkmarks'></span></label></td>
                                        <td class='productimgname'>
                                            <a href='javascript:void(0);'>" . htmlspecialchars($row['full_name']) . "</a>
                                        </td>
                                        <td>" . htmlspecialchars($row['dob']) . "</td>
                                        <td>" . htmlspecialchars($row['address_palestine']) . "</td>
                                        <td>
                                            <a href='https://wa.me/" . htmlspecialchars($row['number']) . "' target='_blank'>" . htmlspecialchars($row['number']) . "</a><br>
                                            <a href='mailto:" . htmlspecialchars($row['Email']) . "'>" . htmlspecialchars($row['Email']) . "</a>
                                        </td>
                                        <td>" . htmlspecialchars($row['university_name']) . "</td>
                                        <td>" . htmlspecialchars($row['major']) . "</td>
                                        <td>" . htmlspecialchars($row['visa_expire_date']) . "</td>
                                        <td><span class='badge $badgeColor'>" . htmlspecialchars($row['status']) . "</span></td>
                                        <td>
    <a class='me-3' href='student-detail.php?id=" . htmlspecialchars($row['id']) . "'>
        <img src='../assets/img/icons/eye.svg' alt='img'>
    </a>
    <div class='dropdown d-inline-block'>
        <a class='me-3 edit-status' href='javascript:void(0);' data-id='" . htmlspecialchars($row['id']) . "' data-status='" . htmlspecialchars($row['status']) . "' data-bs-toggle='dropdown' aria-expanded='false'>
            <img src='../assets/img/icons/edit.svg' alt='img'>
        </a>
        <ul class='dropdown-menu'></ul>
    </div>
    <!-- Add data-id for delete action -->
    <a class='confirm-text delete-record' href='javascript:void(0);' data-id='" . htmlspecialchars($row['id']) . "'>
        <img src='../assets/img/icons/delete.svg' alt='img'>
    </a>
</td>

                                    </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='10'>No records found</td></tr>";
                            }
                            $conn->close();
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Pagination -->
        <nav aria-label="Page navigation">
            <ul class="pagination">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</div>

<!-- Include SweetAlert2 CSS and JS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>

<!-- Status update logic -->
<script defer>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.edit-status').forEach(function (editButton) {
        editButton.addEventListener('click', function (event) {
            const studentId = this.getAttribute('data-id');
            const currentStatus = this.getAttribute('data-status');
            const dropdownMenu = event.currentTarget.nextElementSibling;

            dropdownMenu.innerHTML = ''; 
            let options = generateStatusOptions(currentStatus, studentId);

            dropdownMenu.innerHTML = options;

            // Handle the status change when the dropdown item is clicked
            dropdownMenu.querySelectorAll('a').forEach(function (option) {
                option.addEventListener('click', function (event) {
                    event.preventDefault(); // Prevent default anchor click behavior
                    const newStatus = this.getAttribute('data-status');
                    const userId = this.getAttribute('data-id');

                    // Show confirmation alert
                    Swal.fire({
                        title: 'Are you sure?',
                        text: `Do you want to change the status to "${newStatus}"?`,
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Yes, change it!',
                        cancelButtonText: 'No, cancel!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // AJAX call to update status
                            fetch('../utilities/update-status.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({ id: userId, status: newStatus })
                            })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        Swal.fire('Updated!', data.message, 'success');
                                        // Update the status badge and dropdown options dynamically
                                        const statusCell = editButton.closest('tr').querySelector('td:nth-child(9) span');
                                        statusCell.className = 'badge ' + getBadgeColor(newStatus); // Update badge color
                                        statusCell.textContent = newStatus; // Update badge text
                                        editButton.setAttribute('data-status', newStatus); // Update current status for the next change
                                    } else {
                                        Swal.fire('Error!', data.message, 'error');
                                    }
                                })
                                .catch(error => {
                                    console.error('Error:', error);
                                    Swal.fire('Error!', 'There was an issue updating the status.', 'error');
                                });
                        }
                    });
                });
            });
        });
    });

    // Utility function to generate the status options dynamically
    function generateStatusOptions(currentStatus, studentId) {
        let options = '';
        switch (currentStatus) {
            case 'Pending':
                options = `<li><a class="dropdown-item" href="#" data-status="Rejected" data-id="${studentId}">Rejected</a></li>
                           <li><a class="dropdown-item" href="#" data-status="Approved" data-id="${studentId}">Approved</a></li>`;
                break;
            case 'Rejected':
                options = `<li><a class="dropdown-item" href="#" data-status="Pending" data-id="${studentId}">Pending</a></li>
                           <li><a class="dropdown-item" href="#" data-status="Approved" data-id="${studentId}">Approved</a></li>`;
                break;
            case 'Approved':
                options = `<li><a class="dropdown-item" href="#" data-status="Pending" data-id="${studentId}">Pending</a></li>
                           <li><a class="dropdown-item" href="#" data-status="Rejected" data-id="${studentId}">Rejected</a></li>`;
                break;
            default:
                options = '<li><a class="dropdown-item" href="#">No options available</a></li>';
                break;
        }
        return options;
    }

    // Utility function to get the badge color class based on the status
    function getBadgeColor(status) {
        switch (status) {
            case 'Pending':
                return 'badge-warning';
            case 'Rejected':
                return 'badge-danger';
            case 'Approved':
                return 'badge-success';
            default:
                return 'badge-secondary';
        }
    }
});

</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const filterDropdown = document.getElementById('status-filter');

    filterDropdown.addEventListener('change', function() {
        const selectedStatus = this.value;
        fetchFilteredData(selectedStatus);
    });

    function fetchFilteredData(status) {
        const url = `../utilities/fetch-data.php?status=${status}`; // Adjust the URL to match your fetch endpoint
        fetch(url)
            .then(response => response.text())
            .then(html => {
                document.getElementById('refresh').innerHTML = html; // Ensure this matches your table body ID
            })
            .catch(error => {
                console.error('Error fetching filtered data:', error);
            });
    }
});
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
    // Get all elements with the class 'delete-record'
    const deleteButtons = document.querySelectorAll('.delete-record');

    // Attach click event listeners to each delete button
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id'); // Get the id from data-id attribute

            // Confirm before deleting
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Perform AJAX request to delete the record
                    fetch('../utilities/trash.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ id: id }) // Send the id as JSON data
                    })
                    .then(response => response.json())
                    .then(result => {
                        if (result.success) {
                            Swal.fire({
                                title: 'Deleted!',
                                text: result.message,
                                icon: 'success',
                                confirmButtonColor: '#3085d6'
                            }).then(() => {
                                // Reload the page to reflect changes
                                window.location.reload();
                            });
                        } else {
                            Swal.fire('Error!', result.message, 'error');
                        }
                    })
                    .catch(error => {
                        Swal.fire('Error!', 'There was an error processing your request.', 'error');
                    });
                }
            });
        });
    });
});

</script>

<?php include'inc/footer.php'?>