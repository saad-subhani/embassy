<?php include 'inc/sidebar.php'; ?>

<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>Additional Applications</h4>
                <h6>Manage all Applications</h6>
            </div>
            <div class="page-btn">
                <form method="GET" action="all-applications.php">
                    <select name="filter" class="form-select" onchange="this.form.submit()">
                        <option value="">Select Application Type</option>
                        <option value="contract_submission" <?= (isset($_GET['filter']) && $_GET['filter'] == 'contract_submission') ? 'selected' : '' ?>>Contract Submission</option>
                        <option value="invoice_exchange" <?= (isset($_GET['filter']) && $_GET['filter'] == 'invoice_exchange') ? 'selected' : '' ?>>Invoice Exchange</option>
                        <option value="document_review" <?= (isset($_GET['filter']) && $_GET['filter'] == 'document_review') ? 'selected' : '' ?>>Document Review</option>
                        <option value="file_upload" <?= (isset($_GET['filter']) && $_GET['filter'] == 'file_upload') ? 'selected' : '' ?>>File Upload</option>
                        <option value="other" <?= (isset($_GET['filter']) && $_GET['filter'] == 'other') ? 'selected' : '' ?>>Other</option>
                    </select>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>
                                    <label class="checkboxs">
                                        <input type="checkbox" id="select-all">
                                        <span class="checkmarks"></span>
                                    </label>
                                </th>
                                <th>Title</th>
                                <th>Application For</th>
                                <th>Content</th>
                                <th>Date</th>
                                <th>Application By</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php
                        include '../utilities/conn.php';

                        // Define how many results you want per page
                        $results_per_page = 20;

                        // Get the current page number from the URL, defaulting to 1 if not set
                        $current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

                        // Calculate the starting row for the SQL query
                        $start_from = ($current_page - 1) * $results_per_page;

                        // Get filter option if set
                        $filter = isset($_GET['filter']) ? $_GET['filter'] : '';

                        // SQL query to fetch data from the applications table and join with users
                        $sql = "SELECT a.id, a.title, a.application_for, a.content, a.user_id, a.created_at, u.full_name 
                                FROM applications a 
                                LEFT JOIN users u ON a.user_id = u.id ";

                        // Add filtering condition if a filter is selected
                        if ($filter) {
                            $sql .= " WHERE a.application_for = '$filter' ";
                        }

                        // Add pagination to the query
                        $sql .= " LIMIT $start_from, $results_per_page"; 

                        // Execute the query
                        $result = $conn->query($sql);

                        // Check if the query was successful
                        if (!$result) {
                            // Output error message if query fails
                            die("SQL Error: " . $conn->error);
                        }

                        // Check if there are results
                        if ($result->num_rows > 0) {
                            // Loop through and display each record
                            while ($row = $result->fetch_assoc()) {
                                // Format the created_at date to d/m/Y
                                $formattedDate = date('d/m/Y', strtotime($row['created_at']));

                                echo "<tr>
                                    <td>
                                        <label class='checkboxs'>
                                            <input type='checkbox'>
                                            <span class='checkmarks'></span>
                                        </label>
                                    </td>
                                    <td>{$row['title']}</td>
                                    <td>{$row['application_for']}</td>
                                    <td>{$row['content']}</td>
                                    <td>{$formattedDate}</td>
                                    <td>{$row['full_name']}</td>
                                    <td>
                                        <a class='me-3' href='view-application.php?id={$row['id']}'>
                                            <img src='../assets/img/icons/eye.svg' alt='View'>
                                        </a>
                                        <a class='me-3' href='edit-application.php?id={$row['id']}'>
                                            <img src='../assets/img/icons/edit.svg' alt='Edit'>
                                        </a>
                                        <a class='confirm-text' href='javascript:void(0);' onclick='confirmDelete({$row['id']});'>
                                            <img src='../assets/img/icons/delete.svg' alt='Delete'>
                                        </a>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>No records found</td></tr>";
                        }

                        // Close the connection
                        $conn->close();
                        ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination Logic -->
                <div class="pagination">
                    <?php
                    // Reconnect to the database to count total applications
                    include '../utilities/conn.php';
                    $sql = "SELECT COUNT(*) AS total FROM applications";
                    
                    // Add filtering condition to count if a filter is selected
                    if ($filter) {
                        $sql .= " WHERE application_for = '$filter'";
                    }

                    $result = $conn->query($sql);
                    $row = $result->fetch_assoc();
                    $total_results = $row['total'];

                    // Calculate total pages
                    $total_pages = ceil($total_results / $results_per_page);

                    // Display pagination links
                    echo '<nav aria-label="Page navigation">';
                    echo '<ul class="pagination">';
                    for ($i = 1; $i <= $total_pages; $i++) {
                        if ($i == $current_page) {
                            echo "<li class='page-item active'><span class='page-link'>{$i}</span></li>";
                        } else {
                            echo "<li class='page-item'><a class='page-link' href='all-applications.php?page={$i}&filter={$filter}'>{$i}</a></li>";
                        }
                    }
                    echo '</ul>';
                    echo '</nav>';

                    // Close the connection
                    $conn->close();
                    ?>
                </div>

                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- Include SweetAlert2 -->
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- Ensure jQuery is included -->

                <script>
                    // Function to handle delete confirmation
                    function confirmDelete(id) {
                        Swal.fire({
                            title: 'Are you sure?',
                            text: "You won't be able to revert this!",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#d33',
                            cancelButtonColor: '#3085d6',
                            confirmButtonText: 'Yes, delete it!'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                // Send AJAX request to delete the record
                                $.ajax({
                                    url: '../utilities/delete-application.php', // URL to your delete script
                                    type: 'POST',
                                    data: { id: id },
                                    dataType: 'json', // Expect JSON response
                                    success: function(response) {
                                        // Check response status
                                        if (response.success) {
                                            Swal.fire(
                                                'Deleted!',
                                                'Your application has been deleted.',
                                                'success'
                                            ).then(() => {
                                                // Refresh the page or remove the row from the table
                                                location.reload();
                                            });
                                        } else {
                                            Swal.fire(
                                                'Error!',
                                                response.error || 'There was a problem deleting your application.',
                                                'error'
                                            );
                                        }
                                    },
                                    error: function() {
                                        Swal.fire(
                                            'Error!',
                                            'There was a problem with the AJAX request.',
                                            'error'
                                        );
                                    }
                                });
                            }
                        });
                    }
                </script>
            </div>
        </div>
    </div>
</div>

<?php include 'inc/footer.php'; ?>
