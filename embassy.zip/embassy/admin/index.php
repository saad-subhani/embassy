<?php include 'inc/sidebar.php'; ?>
<style>
    .custom-badge {
        display: inline-block;
        padding: 0.5em 0.75em;
        font-size: 0.75rem;
        font-weight: 700;
        color: #fff;
        border-radius: 0.25rem;
    }
    .badge-warning { background-color: #e0a800; }
    .badge-danger { background-color: #dc3545; }
    .badge-success { background-color: #28a745; }
    .badge-secondary { background-color: #6c757d; }
</style>

<div class="page-wrapper">
<div class="content">
<div class="row">

<?php
include "../utilities/conn.php"; // Include your database connection

// Query to get the total counts based on the status
$totalStudentsQuery = "SELECT COUNT(*) AS total_students FROM user_information";
$documentsInProcessQuery = "SELECT COUNT(*) AS documents_in_process FROM user_information WHERE status = 'Pending'";
$studentsRejectedQuery = "SELECT COUNT(*) AS students_rejected FROM user_information WHERE status = 'Rejected'";
$studentsApprovedQuery = "SELECT COUNT(*) AS students_approved FROM user_information WHERE status = 'Approved'";

$totalStudentsResult = $conn->query($totalStudentsQuery);
$documentsInProcessResult = $conn->query($documentsInProcessQuery);
$studentsRejectedResult = $conn->query($studentsRejectedQuery);
$studentsApprovedResult = $conn->query($studentsApprovedQuery);

// Fetch the results
$totalStudents = $totalStudentsResult->fetch_assoc()['total_students'];
$documentsInProcess = $documentsInProcessResult->fetch_assoc()['documents_in_process'];
$studentsRejected = $studentsRejectedResult->fetch_assoc()['students_rejected'];
$studentsApproved = $studentsApprovedResult->fetch_assoc()['students_approved'];

$conn->close(); // Close the database connection
?>


<div class="col-lg-3 col-sm-6 col-12 d-flex">
    <div class="dash-count das2">
        <div class="dash-counts">
            <h4><?php echo $totalStudents; ?></h4>
            <h5>Total Students</h5>
        </div>
        <div class="dash-imgs">
            <i data-feather="file-text"></i>
        </div>
    </div>
</div>
<div class="col-lg-3 col-sm-6 col-12 d-flex">
    <div class="dash-count">
        <div class="dash-counts">
            <h4><?php echo $documentsInProcess; ?></h4>
            <h5>Documents in Process</h5>
        </div>
        <div class="dash-imgs">
            <i data-feather="user"></i>
        </div>
    </div>
</div>
<div class="col-lg-3 col-sm-6 col-12 d-flex">
    <div class="dash-count das1">
        <div class="dash-counts">
            <h4><?php echo $studentsRejected; ?></h4>
            <h5>Students Rejected</h5>
        </div>
        <div class="dash-imgs">
        <i data-feather="file"></i>
        </div>
    </div>
</div>
<div class="col-lg-3 col-sm-6 col-12 d-flex">
    <div class="dash-count das3">
        <div class="dash-counts">
            <h4><?php echo $studentsApproved; ?></h4>
            <h5>Students Approved</h5>
        </div>
        <div class="dash-imgs">
            <i data-feather="user-check"></i>
        </div>
    </div>
</div>
</div>

<?php
include "../utilities/conn.php"; // Include database connection

// Query to count approved, rejected, and pending users
$query = "SELECT status, COUNT(*) as count FROM user_information WHERE status IN ('Approved', 'Rejected', 'Pending') GROUP BY status";
$result = $conn->query($query);

$approvedCount = 0;
$rejectedCount = 0;
$pendingCount = 0; // Initialize pending count

// Process the result
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row['status'] === 'Approved') {
            $approvedCount = $row['count'];
        } elseif ($row['status'] === 'Rejected') {
            $rejectedCount = $row['count'];
        } elseif ($row['status'] === 'Pending') {
            $pendingCount = $row['count'];
        }
    }
} else {
    // Handle the case where no records are found
}

$conn->close(); // Close the database connection
?>


<div class="row">
<div class="col-lg-7 col-sm-12 col-12 d-flex">
    <div class="card flex-fill">
        <div class="card-header pb-0 d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">User Approval Status</h5>
        </div>
        <div class="card-body">
            <div id="userChart" style="height: 350px;"></div> <!-- Container for ECharts -->
        </div>
    </div>
</div>

<!-- Include ECharts Library -->
<script src="https://cdn.jsdelivr.net/npm/echarts/dist/echarts.min.js"></script>
<script>
    // Fetch counts from PHP
    const approvedCount = <?php echo $approvedCount; ?>;
    const rejectedCount = <?php echo $rejectedCount; ?>;
    const pendingCount = <?php echo $pendingCount; ?>; // Add pending count

    // Initialize ECharts
    const myChart = echarts.init(document.getElementById('userChart'));

    // Set chart options
    const options = {
        title: {
            text: 'User Approval Status',
            left: 'center',
            textStyle: {
                color: '#333',
                fontSize: 16,
                fontWeight: 'bold',
            }
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c} ({d}%)',
            backgroundColor: '#333',
            borderColor: '#777',
            borderWidth: 1,
            textStyle: {
                color: '#fff'
            }
        },
        legend: {
            orient: 'vertical',
            left: 'left',
            data: ['Approved', 'Rejected', 'Pending'], // Include Pending in legend
            textStyle: {
                color: '#666'
            }
        },
        series: [
            {
                name: 'User Status',
                type: 'pie',
                radius: '55%',
                center: ['50%', '60%'],
                data: [
                    { value: approvedCount, name: 'Approved' },
                    { value: rejectedCount, name: 'Rejected' },
                    { value: pendingCount, name: 'Pending' } // Add Pending data
                ],
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                },
                itemStyle: {
                    borderRadius: 10,
                    borderColor: '#fff',
                    borderWidth: 2
                },
                label: {
                    formatter: '{b}: {c} ({d}%)',
                    color: '#333',
                    fontSize: 14,
                }
            }
        ],
        color: ['#00E396', '#FF4560', '#FF9F43'], // Custom colors for segments including Pending
    };

    // Set the options for the chart
    myChart.setOption(options);

    // Resize chart on window resize
    window.addEventListener('resize', function() {
        myChart.resize();
    });
</script>


<div class="col-lg-5 col-sm-12 col-12 d-flex">
<div class="card flex-fill">
<div class="card-header pb-0 d-flex justify-content-between align-items-center">
<h4 class="card-title mb-0">Recent Applications</h4>
<div class="dropdown">
<a href="javascript:void(0);" data-bs-toggle="dropdown" aria-expanded="false" class="dropset">
<i class="fa fa-ellipsis-v"></i>
</a>
<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
<li>
<a href="productlist.html" class="dropdown-item">Application List</a>
</li>

</ul>
</div>
</div>
<div class="card-body">
<div class="table-responsive dataview">
<table class="table datatable ">
<thead>
<tr>
    <th>Sr no</th>
<th>Title</th>
<th>Reason</th>
</tr>
</thead>
<tbody>

<?php
include '../utilities/conn.php';

// SQL query to fetch the latest 5 records from the applications table
$sql = "SELECT id, title, application_for, content FROM applications ORDER BY id DESC LIMIT 5"; // Assuming 'id' is the column to determine the latest records
$result = $conn->query($sql);

// Check if there are results
if ($result->num_rows > 0) {
    // Loop through and display each record
    while ($row = $result->fetch_assoc()) {
        // Determine the badge color based on status

        echo "<tr>
            <td>
                <label class='checkboxs'>
                    <input type='checkbox'>
                    <span class='checkmarks'></span>
                </label>
            </td>
            <td>{$row['title']}</td>
            <td>{$row['application_for']}</td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='3'>No records found</td></tr>"; // Adjusted colspan to match the number of columns displayed
}

// Close the connection
$conn->close();
?>

</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
<div class="card mb-0">
<div class="card-body">
<h4 class="card-title">Expired Products</h4>
<?php
include "../utilities/conn.php"; // Include database connection

// Query to select the latest 5 records, assuming you have a column to order by (e.g., 'id' or 'created_at')
$query = "SELECT * FROM user_information ORDER BY id DESC LIMIT 5"; // Change 'id' to your relevant column if needed
$result = $conn->query($query); // Execute the query
?>
<div class="table-responsive">
    <table class="table">
        <thead>
            <tr>
                <th><label class="checkboxs"><input type="checkbox" id="select-all"><span class="checkmarks"></span></label></th>
                <th>Full Name</th>
                <th>Date of Birth</th>
                <th>Address (Palestine)</th>
                <th>Contact Info</th>
                <th>University Name</th>
                <th>Major</th>
                <th>Visa Expiry Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody id="refresh">
            <?php
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    // Determine badge color
                    if ($row['status'] == 'Pending') {
                        $badgeColor = 'badge-warning';
                    } elseif ($row['status'] == 'Rejected') {
                        $badgeColor = 'badge-danger';
                    } elseif ($row['status'] == 'Approved') {
                        $badgeColor = 'badge-success';
                    } else {
                        $badgeColor = 'badge-secondary';
                    }

                    // Output the row
                    echo "<tr>
                        <td><label class='checkboxs'><input type='checkbox'><span class='checkmarks'></span></label></td>
                        <td class='productimgname'><a href='javascript:void(0);'>" . htmlspecialchars($row['full_name']) . "</a></td>
                        <td>" . htmlspecialchars($row['dob']) . "</td>
                        <td>" . htmlspecialchars($row['address_palestine']) . "</td>
                        <td>
                            <a href='https://wa.me/" . htmlspecialchars($row['number']) . "' target='_blank'>" . htmlspecialchars($row['number']) . "</a><br>
                            <a href='mailto:" . htmlspecialchars($row['Email']) . "'>" . htmlspecialchars($row['Email']) . "</a>
                        </td>
                        <td>" . htmlspecialchars($row['university_name']) . "</td>
                        <td>" . htmlspecialchars($row['major']) . "</td>
                        <td>" . htmlspecialchars($row['visa_expire_date']) . "</td>
                        <td><span class='badge $badgeColor'>" . htmlspecialchars($row['status']) . "</span></td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='10'>No records found</td></tr>";
            }
            $conn->close(); // Close the database connection
            ?>
        </tbody>
    </table>
</div>

</div>
</div>
</div>
</div>
</div>


<?php include'inc/footer.php'?>