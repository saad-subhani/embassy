<?php include'inc/sidebar.php';?>


<div class="page-wrapper">
<div class="content">
    <!-- Include Notyf CSS and JavaScript -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
<script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>
<script src="https://kit.fontawesome.com/4e21418a03.js" crossorigin="anonymous"></script>

<script>
    // Initialize Notyf
    var notyf = new Notyf({
        duration: 4000, // 5 seconds timeout
        position: {
            x: 'center',
            y: 'top'
        }
    });

    // Pass the PHP variable userName to JavaScript
    <?php if (isset($user_name)): ?>
        var userName = "<?php echo $user_name; ?>";
    <?php endif; ?>

    // Check if userName is set from the PHP part
    if (typeof userName !== 'undefined') {
        // Display the Notyf welcome notification
        notyf.success('Hello ' + userName + ', welcome back!');
    }
</script>

<style>
    #cursor {
        cursor: pointer !important;
    }
</style>
    
<div class="row">

<div class="col-lg-4 col-sm-6 col-12 d-flex">
<div class="dash-count" id="cursor" onclick="window.location.href='student-history.php';">
<div class="dash-counts">
<h4>Announcements</h4>
<h5>View Announcementa</h5>
</div>
<div class="dash-imgs">
<i data-feather="user"></i>
</div>
</div>
</div>
<div class="col-lg-4 col-sm-6 col-12 d-flex">
<div class="dash-count das1" id="cursor" onclick="window.location.href='student-history.php';">
  <div class="dash-counts">
    <h4>Instructions</h4>
    <h5>View Instructions</h5>
  </div>
  <div class="dash-imgs">
    <i data-feather="user-check"></i>
  </div>
</div>

</div>
<div class="col-lg-4 col-sm-6 col-12 d-flex">
<div class="dash-count das2" id="cursor" onclick="window.location.href='student-profile.php';">
<div class="dash-counts">
<h4>Student Details</h4>
<h5>View Your Details</h5>
</div>
<div class="dash-imgs">
<i data-feather="file-text"></i>
</div>
</div>
</div>

</div>

<div class="row">

<div class="col-lg-4 col-sm-6 col-12 d-flex">
<div class="dash-count" id="cursor" onclick="window.location.href='student-status.php';">
<div class="dash-counts">
<h4>Status</h4>
<h5>View Documents Status</h5>
</div>
<div class="dash-imgs">
<i data-feather="user"></i>
</div>
</div>
</div>
<div class="col-lg-4 col-sm-6 col-12 d-flex">
<div class="dash-count das1" id="cursor" onclick="window.location.href='mailto:saadsubhani@gmail.com';">
  <div class="dash-counts">
    <h4>Contact</h4>
    <h5>Contact us now</h5>
  </div>
  <div class="dash-imgs">
    <i data-feather="user-check"></i>
  </div>
</div>

</div>


</div>


</div>
</div>



<?php include'inc/footer.php';?>