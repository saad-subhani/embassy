<?php include 'inc/sidebar.php'; ?>




<style>
    .courses-container {
  width: 1142px;
  margin: 0 auto;
}

.courses-box {
  display: flex;
  flex-wrap: wrap;
  padding: 50px 0;
}

.course-item {
  flex-basis: calc(33.33333% - 30px);
  margin: 0 15px 30px;
  overflow: hidden;
  border-radius: 20px;
}

.course-link {
  display: block;
  padding: 20px 15px;
  background-color: #121212;
  overflow: hidden;
  position: relative;
  border-radius: 15px;
  transition: background-color 0.3s ease;
}

.course-link:hover {
  color: #FFF;
}

/* Hover colors for specific teams */
#team1-1 .course-link:hover {
  background-color: #f9b234; /* Yellow */
}

#team1-2 .course-link:hover {
  background-color: #3ecd5e; /* Green */
}

#team1-3 .course-link:hover {
  background-color: #952aff; /* Purple */
}

.course-title {
  min-height: 60px;
  margin: 0 0 15px;
  overflow: hidden;
  font-weight: bold;
  font-size: 24px;
  color: #FFF;
  z-index: 2;
  position: relative;
}

.course-date-box {
  font-size: 16px;
  color: #FFF;
  z-index: 2;
  position: relative;
}

.course-date {
  font-weight: bold;
  color: #FFF;
  transition: color .5s ease;
}

.course-background {
  height: 100px;
  width: 100px;
  background-color: #f9b234;
  z-index: 1;
  position: absolute;
  top: -50px;
  right: -50px;
  border-radius: 50%;
  transition: all .5s ease;
}

/* Background colors for specific teams */
#team1-1 .course-background {
  background-color: #f9b234; /* Yellow */
}

#team1-2 .course-background {
  background-color: #3ecd5e; /* Green */
}

#team1-3 .course-background {
  background-color: #952aff; /* Purple */
}

.course-image {
  width: 100%;
  height: auto;
}

@media only screen and (max-width: 979px) {
  .course-item {
    flex-basis: calc(50% - 30px);
  }
  .course-title {
    font-size: 20px;
  }
}

@media only screen and (max-width: 767px) {
  .courses-container {
    width: 96%;
  }
}

@media only screen and (max-width: 639px) {
  .course-item {
    flex-basis: 100%;
  }
  .course-title {
    min-height: 60px;
    font-size: 20px;
  }
  .course-link {
    padding: 15px 10px;
  }
  .course-date-box {
    font-size: 14px;
  }
}

</style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />

<style>
    .gallery-item {
        cursor: pointer;
        margin-bottom: 20px;
        padding: 20px;
        background-color: #1B2850;
        border-radius: 5px;
        text-align: center;
        color:white;
    }

    .gallery-item:hover {
        background-color: #FF9F43;
        color:black;
    }

    /* Modal background */
    .modal-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.9); /* Black transparent background */
        z-index: 9999;
        justify-content: center;
        align-items: center;
        overflow: hidden; /* Prevent scrolling the background */
    }

    /* Modal content */
    .modal-content {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        max-width: 90%; /* Ensure content doesn't exceed viewport width */
        max-height: 90%; /* Ensure content doesn't exceed viewport height */
        overflow: auto; /* Allow scrolling within the modal */
    }

    /* Close button */
    .close-button {
        position: absolute;
        top: 10px;
        right: 20px;
        color: #fff;
        font-size: 30px;
        cursor: pointer;
        z-index: 10000;
    }

    /* Image inside the modal */
    .modal-image {
        display: block;
        max-width: none; /* Allow image to exceed default width */
        max-height: none; /* Allow image to exceed default height */
        object-fit: contain; /* Ensure the image maintains aspect ratio */
        transition: transform 0.2s ease-in-out;
    }

    /* Hide the modal by default */
    .hidden {
        display: none;
    }

    /* Controls for zooming */
    .zoom-controls {
        position: absolute;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 10001;
        display: flex;
        gap: 10px;
    }

    /* Buttons for zoom and download */
    .control-button {
        background-color: green; /* Green background */
        padding: 10px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .control-button i {
        margin-right: 5px;
    }

    .control-button:hover {
        background-color: darkgreen;
    }

    /* Container for the scrolling image */
    .image-container {
        display: flex;
        justify-content: center;
        align-items: center;
        max-width: 100%; /* Limit container width */
        max-height: 100%; /* Limit container height */
        overflow: auto; /* Allow scrolling if the image exceeds the container size */
    }
</style>
<!-- Add CSS for selected tab color and layout -->
<style>
  .nav-tabs .nav-link.active {
    background-color: #FF9F43;
    color: white;
  }

  .nav-tabs .nav-link {
    color: #000; /* Default text color for unselected tabs */
  }

  /* Custom tab width */
  .custom-tab {
    flex: 1 1 20%; /* Set equal width for each tab (5 tabs in total, so 20% each) */
  }

  .nav-tabs {
    display: flex;
    width: 100%; /* Ensure full width of container */
  }

  .nav-link {
    text-align: center;
    width: 100%; /* Make links fill the full width of their parent */
  }
</style>
<style>
    .noc-gallery-item {
        cursor: pointer;
        margin-bottom: 20px;
        padding: 20px;
        background-color: #f2f2f2;
        border-radius: 5px;
        text-align: center;
    }

    .noc-gallery-item:hover {
        background-color: #e0e0e0;
    }

    /* Modal background */
    .noc-modal-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.9); /* Black transparent background */
        z-index: 9999;
        justify-content: center;
        align-items: center;
        overflow: hidden; /* Prevent scrolling the background */
    }

    /* Modal content */
    .noc-modal-content {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        max-width: 90%; /* Ensure content doesn't exceed viewport width */
        max-height: 90%; /* Ensure content doesn't exceed viewport height */
        overflow: auto; /* Allow scrolling within the modal */
    }

    /* Close button */
    .noc-close-button {
        position: absolute;
        top: 10px;
        right: 20px;
        color: #fff;
        font-size: 30px;
        cursor: pointer;
        z-index: 10000;
    }

    /* Image inside the modal */
    .noc-modal-image {
        display: block;
        max-width: none; /* Allow image to exceed default width */
        max-height: none; /* Allow image to exceed default height */
        object-fit: contain; /* Ensure the image maintains aspect ratio */
        transition: transform 0.2s ease-in-out;
    }

    /* Hide the modal by default */
    .noc-hidden {
        display: none;
    }

    /* Controls for zooming */
    .noc-zoom-controls {
        position: absolute;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 10001;
        display: flex;
        gap: 10px;
    }

    /* Buttons for zoom and download */
    .noc-control-button {
        background-color: green; /* Green background */
        padding: 10px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .noc-control-button i {
        margin-right: 5px;
    }

    .noc-control-button:hover {
        background-color: darkgreen;
    }

    /* Container for the scrolling image */
    .noc-image-container {
        display: flex;
        justify-content: center;
        align-items: center;
        max-width: 100%; /* Limit container width */
        max-height: 100%; /* Limit container height */
        overflow: auto; /* Allow scrolling if the image exceeds the container size */
    }
</style>

<div class="page-wrapper">
  <div class="content">
 
    <!-- Bootstrap container for full-width tabs -->
    <div class="container">
    <?php
// Start the session to access session variables

// Check if the user is logged in by checking if 'user_id' is set in the session
if (!isset($_SESSION['user_id'])) {
    echo "<script>console.log('You are not logged in. Please log in to view details.');</script>";
    exit();
}

$user_id = $_SESSION['user_id']; // Get the user_id from the session

// Database connection
include '../utilities/conn.php';

// Fetch student details based on the session user_id
$sql = "SELECT * FROM user_information WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);  // 'i' indicates the parameter is an integer (user_id)
$stmt->execute();
$result = $stmt->get_result();

// Check if student details exist for the logged-in user
if ($result->num_rows > 0) {
    $student = $result->fetch_assoc(); // Fetch the student details as an associative array

    // Send student details to the console
    echo '     <ul class="nav nav-tabs mb-4" id="myTab2" role="tablist">
    <li class="custom-tab">
      <a class="nav-link active" id="personal-info-tab" data-bs-toggle="tab" href="#personal-info" role="tab"
        aria-controls="personal-info" aria-selected="true">Personal Information</a>
    </li>
    <li class="custom-tab">
      <a class="nav-link" id="documents-tab" data-bs-toggle="tab" href="#documents" role="tab"
        aria-controls="documents" aria-selected="false">Documents</a>
    </li>
    <li class="custom-tab">
      <a class="nav-link" id="noc-tab" data-bs-toggle="tab" href="#noc" role="tab"
        aria-controls="noc" aria-selected="false">NOC</a>
    </li>
    <li class="custom-tab">
      <a class="nav-link" id="letters-tab" data-bs-toggle="tab" href="#letters" role="tab"
        aria-controls="letters" aria-selected="false">Letters</a>
    </li>
    
  </ul>';


    // Close connection
    $stmt->close();
    $conn->close();
} else {
    echo "
    
        <div class='row no-gutters height-self-center'>
            <div class='col-sm-12 text-center align-self-center'>
                <div class='iq-error position-relative'>
                    <img src='../assets/img/application.jpg' class='img-fluid iq-error-img mb-0' alt='' width='350'>
                    <h2 class='mb-0'>Please submit your documents to view your details</h2>
                    <p>Thank you for your co-operation. We Appreciate it!</p>
                    <a class='btn btn-primary d-inline-flex align-items-center mt-3' href='user-information.php'>
                        <i class='ri-home-4-line mr-2'></i>Apply Here
                    </a>
                </div>
            </div>
    </div>
  ";
  include'inc/footer.php';
    exit();
}
?>
 

 <div class="tab-content">
        <div class="tab-pane fade show active" id="personal-info" role="tabpanel" aria-labelledby="personal-info-tab">
        <div class="content-page">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-4">
                        <div class="card card-block p-card">
                        <div class="profile-box">
    <div class="profile-card rounded shadow-sm p-4">
        <img src="../utilities/uploads/<?php echo htmlspecialchars($student['personal_picture']); ?>" alt="Profile Picture" class="avatar-100 rounded-circle d-block mx-auto mb-3 img-fluid">
        <h3 class="font-weight-bold text-black text-center mb-0"><?php echo htmlspecialchars($student['full_name']); ?></h3>
    </div>
    <div class="pro-content rounded border p-4">
        <div class="d-flex align-items-center mb-3">
            <div class="p-icon mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" class="text-primary" width="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 19v-8.93a2 2 0 01.89-1.664l7-4.666a2 2 0 012.22 0l7 4.666A2 2 0 0121 10.07V19M3 19a2 2 0 002 2h14a2 2 0 002-2M3 19l6.75-4.5M21 19l-6.75-4.5M3 10l6.75 4.5M21 10l-6.75 4.5m0 0l-1.14.76a2 2 0 01-2.22 0l-1.14-.76"/>
                </svg>
            </div>
            <p class="mb-0 eml"><?php echo htmlspecialchars($student['Email']); ?></p>
        </div>
        <div class="d-flex align-items-center mb-3">
            <div class="p-icon mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" class="text-primary" width="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 8l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2M5 3a2 2 0 00-2 2v1c0 8.284 6.716 15 15 15h1a2 2 0 002-2v-3.28a1 1 0 00-.684-.948l-4.493-1.498a1 1 0 00-1.21.502l-1.13 2.257a11.042 11.042 0 01-5.516-5.517l2.257-1.128a1 1 0 00.502-1.21L9.228 3.683A1 1 0 008.279 3H5z"/>
                </svg>
            </div>
            <p class="mb-0"><?php echo htmlspecialchars($student['number']); ?></p>
        </div>
            </div>
</div>

</div>
                           
                        </div>
                        <div class="col-lg-8">
                            <div class="card card-block">
                                <div class="card-header d-flex justify-content-between pb-0">
                                    <div class="header-title">
                                        <h4 class="card-title mb-0">Personal Details</h4>
                                    </div>
                                </div>
                                <div class="card-body">

                                    
                                <ul class="list-unstyled mb-0">
    <li class="mb-3">
        <svg xmlns="http://www.w3.org/2000/svg" class="text-primary mr-2" width="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" />
        </svg>
        Full Name: <?php echo htmlspecialchars($student['full_name']); ?>
    </li>
    <li class="mb-3">
        <svg xmlns="http://www.w3.org/2000/svg" class="text-primary mr-2" width="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" />
        </svg>
        Father's Name: <?php echo htmlspecialchars($student['father_name']); ?>
    </li>
    <li class="mb-3">
        <svg xmlns="http://www.w3.org/2000/svg" class="text-primary mr-2" width="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" />
        </svg>
        Date of Birth: <?php echo htmlspecialchars($student['dob']); ?>
    </li>
    <li class="mb-3">
        <svg xmlns="http://www.w3.org/2000/svg" class="text-primary mr-2" width="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" />
        </svg>
        Address in Palestine: <?php echo htmlspecialchars($student['address_palestine']); ?>
    </li>
    <li class="mb-3">
        <svg xmlns="http://www.w3.org/2000/svg" class="text-primary mr-2" width="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" />
        </svg>
        Address in Pakistan: <?php echo htmlspecialchars($student['address_pakistan']); ?>
    </li>
   
</ul>
                            
                                </div>
                            </div>
                            <div class="card card-block">
                                <div class="card-header pb-0">
                                    <div class="header-title">
                                        <h4 class="card-title">Education</h4>
                                    </div>
                                </div>
                                <div class="card-body">
    <ul class="list-unstyled p-0 m-0">
        <li class="d-flex align-items-start mb-4">
            <div class="profile-icon iq-icon-box rounded-circle bg-primary-light svg-primary text-center p-3">
                <svg width="24" height="28" viewBox="0 0 24 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M17.1107 17.1746L12 22.2853L6.88929 17.1746C3.05893 17.3406 0 20.4746 0 24.3424V24.8567C0 26.2764 1.15179 27.4281 2.57143 27.4281H21.4286C22.8482 27.4281 24 26.2764 24 24.8567V24.3424C24 20.4746 20.9411 17.3406 17.1107 17.1746ZM0.728571 4.27457L1.07143 4.35493V7.4835C0.696429 7.7085 0.428571 8.09957 0.428571 8.571C0.428571 9.021 0.675 9.396 1.02321 9.62636L0.1875 12.9639C0.0964286 13.3335 0.3 13.7139 0.594643 13.7139H2.83393C3.12857 13.7139 3.33214 13.3335 3.24107 12.9639L2.40536 9.62636C2.75357 9.396 3 9.021 3 8.571C3 8.09957 2.73214 7.7085 2.35714 7.4835V4.66564L5.89286 5.51743C5.43214 6.43886 5.14286 7.46743 5.14286 8.571C5.14286 12.3585 8.2125 15.4281 12 15.4281C15.7875 15.4281 18.8571 12.3585 18.8571 8.571C18.8571 7.46743 18.5732 6.43886 18.1071 5.51743L23.2661 4.27457C24.2411 4.03886 24.2411 2.82278 23.2661 2.58707L13.0661 0.122784C12.3696 -0.0432879 11.6357 -0.0432879 10.9393 0.122784L0.728571 2.58171C-0.241071 2.81743 -0.241071 4.03886 0.728571 4.27457Z" fill="currentColor"/>
                </svg>
            </div>
            <div class="ml-3">
    <h4 class="text-black font-weight-bold mb-1">
        University Name: <span class="text-info"><?php echo htmlspecialchars($student['university_name']); ?></span>
    </h4>
    <h6 class="text-secondary mb-0">
        Major: <span class="text-info"><?php echo htmlspecialchars($student['major']); ?></span>
    </h6>
    <h6 class="text-muted mb-0">
        Student ID: <span class="text-info"><?php echo htmlspecialchars($student['student_id']); ?></span>
    </h6>
</div>

        </li>
    </ul>
</div>

                            </div>
                            
                        </div>
                        <div class="container">
    <div class="row text-center">
        <!-- Card 1: Visa Start Date -->
        <div class="col-sm-4 col-lg-6 mb-4">
            <div class="card card-block card-stretch card-height shadow">
                <div class="card-body">
                    <i class="fas fa-calendar-alt fa-3x text-success mb-3"></i>
                    <h2 class="text-success mb-2">Visa Start Date</h2>
                    <h4 class="font-weight-bold">
                        <?php echo htmlspecialchars($student['visa_start_date']); ?>
                    </h4>
                </div>
            </div>
        </div>

        <!-- Card 2: Visa Expire Date -->
        <div class="col-sm-4 col-lg-6 mb-4">
            <div class="card card-block card-stretch card-height shadow">
                <div class="card-body">
                    <i class="fas fa-calendar-check fa-3x text-danger mb-3"></i>
                    <h2 class="text-danger mb-2">Visa Expire Date</h2>
                    <h4 class="font-weight-bold">
                        <?php echo htmlspecialchars($student['visa_expire_date']); ?>
                    </h4>
                </div>
            </div>
        </div>
    </div>
</div>


</div>

                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade" id="documents" role="tabpanel" aria-labelledby="documents-tab">
    <div class="course-item" id="team1-1">
    <?php
// Start the session to access session variables

// Include your database connection file
include '../utilities/conn.php';

// Check if the user is logged in by verifying if 'user_id' is set in the session
if (!isset($_SESSION['user_id'])) {
    echo "You are not logged in. Please log in to view your documents.";
    exit();
}

$user_id = $_SESSION['user_id']; // Fetch the user_id from the session

// Fetch the documents based on the user_id
$sql = "SELECT visa_application, visa_fee_receipt, passport_copy, photo, verification_degree, verification_transcript 
        FROM uploaded_documents 
        WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id); // Bind the user_id parameter
$stmt->execute();
$result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Fetch the data
            $document = $result->fetch_assoc();
        ?>
            <!-- HTML structure for the gallery -->
            <div class="gallery">
                <div class="gallery-item" onclick="openModal('visa_application')">Visa Application</div>
                <div class="gallery-item" onclick="openModal('visa_fee_receipt')">Visa Fee Receipt</div>
                <div class="gallery-item" onclick="openModal('passport_copy')">Passport Copy</div>
                <div class="gallery-item" onclick="openModal('photo')">Photo</div>
                <div class="gallery-item" onclick="openModal('verification_degree')">Verification Degree</div>
                <div class="gallery-item" onclick="openModal('verification_transcript')">Verification Transcript</div>
            </div>

            <!-- Modal structure -->
            <div id="modal" class="modal-overlay" style="display: none;">
                <span class="close-button" onclick="closeModal()">&times;</span>
                <div class="modal-content" style="background-color:none !important;">
                    <div class="image-container">
                        <img id="modalImage" class="modal-image" src="" alt="Document Image">
                    </div>
                </div>
                <!-- Zoom controls -->
                <div class="zoom-controls">
                    <span class="control-button" onclick="zoomIn()">
                        <i class="fas fa-search-plus"></i> Zoom In
                    </span>
                    <span class="control-button" onclick="zoomOut()">
                        <i class="fas fa-search-minus"></i> Zoom Out
                    </span>
                    <span class="control-button" onclick="downloadImage()">
                        <i class="fas fa-download"></i> Download
                    </span>
                </div>
            </div>

            <!-- JavaScript to handle modal opening, closing, zooming, and downloading -->
            <script>
                // Mapping of documents
                const documents = {
                    visa_application: "<?php echo '../utilities/' . htmlspecialchars($document['visa_application']); ?>",
                    visa_fee_receipt: "<?php echo '../utilities/' . htmlspecialchars($document['visa_fee_receipt']); ?>",
                    passport_copy: "<?php echo '../utilities/' . htmlspecialchars($document['passport_copy']); ?>",
                    photo: "<?php echo '../utilities/' . htmlspecialchars($document['photo']); ?>",
                    verification_degree: "<?php echo '../utilities/' . htmlspecialchars($document['verification_degree']); ?>",
                    verification_transcript: "<?php echo '../utilities/' . htmlspecialchars($document['verification_transcript']); ?>"
                };

                let currentZoom = 1; // Initialize zoom level

                // Function to open the modal with the corresponding image
                function openModal(docKey) {
                    const modal = document.getElementById('modal');
                    const modalImage = document.getElementById('modalImage');
                    modalImage.src = documents[docKey]; // Set the image source
                    modalImage.style.transform = 'scale(1)'; // Reset zoom on open
                    currentZoom = 1; // Reset zoom level
                    modal.style.display = 'flex'; // Make modal visible
                }

                // Function to close the modal
                function closeModal() {
                    const modal = document.getElementById('modal');
                    modal.style.display = 'none'; // Hide modal
                }

                // Function to zoom in the image
                function zoomIn() {
                    const modalImage = document.getElementById('modalImage');
                    currentZoom += 0.2; // Increase zoom level
                    modalImage.style.transform = `scale(${currentZoom})`; // Apply zoom
                }

                // Function to zoom out the image
                function zoomOut() {
                    const modalImage = document.getElementById('modalImage');
                    if (currentZoom > 0.4) { // Prevent zooming out too much
                        currentZoom -= 0.2; // Decrease zoom level
                        modalImage.style.transform = `scale(${currentZoom})`; // Apply zoom
                    }
                }

                // Function to download the image
                function downloadImage() {
                    const modalImage = document.getElementById('modalImage');
                    const link = document.createElement('a');
                    link.href = modalImage.src; // Get the source of the image
                    const filename = modalImage.src.split('/').pop(); // Get the original filename
                    link.download = filename; // Use the original filename for download
                    document.body.appendChild(link);
                    link.click(); // Trigger the download
                    document.body.removeChild(link); // Remove the link element after download
                }

                // Close modal when clicking outside of the image
                document.getElementById('modal').addEventListener('click', function(event) {
                    if (event.target === this) {
                        closeModal();
                    }
                });

                // Close modal with Esc key
                document.addEventListener('keydown', function(event) {
                    if (event.key === "Escape") {
                        closeModal();
                    }
                });
            </script>
        <?php
        } else {
            // If student not found, display an error message
        ?>
            <div class="tab-content">
                <div class="tab-pane fade show active" id="personal-info" role="tabpanel" aria-labelledby="personal-info-tab">
                    <div class="content-page">
                        <div class="container-fluid">
                            <div class="alert alert-danger" role="alert">
                                <strong>Empty!</strong> You didn't fill the Documents form yet. Fill <a href="documents-upload.php">here</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
        ?>
    </div>
</div>

<div class="tab-pane fade" id="noc" role="tabpanel" aria-labelledby="noc-tab" style="margin-top:-100px;">
    <?php

    // Include your database connection file
    include '../utilities/conn.php';

    // Check if the user is logged in by verifying if 'user_id' is set in the session
    if (!isset($_SESSION['user_id'])) {
        echo "You are not logged in. Please log in to view your documents.";
        exit();
    }

    $user_id = $_SESSION['user_id']; // Fetch the user_id from the session

    // Fetch the documents based on the user_id
    $sql = "SELECT passport_extension_study_visa, last_visa_extension_study_visa, supporting_docs_extension_study_visa, 
            passport_account_opening, last_visa_account_opening, supporting_docs_account_opening, 
            certificate_school_equivalence, admission_letter_equivalence, supporting_docs_equivalence, 
            supporting_docs_other_purposes, degree_authorized_letter, passport_authorized_letter, 
            authorized_person_id, supporting_docs_authorized_letter 
            FROM noc_documents WHERE user_id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id); // Bind the user_id parameter
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch the data
        $document = $result->fetch_assoc();
        ?>

        <!-- Styles for the modal effect, zooming, centering, and scrolling gallery -->

        <!-- HTML structure for the NOC gallery -->
        <div class="noc-gallery">
            <div class="noc-gallery-item" onclick="openNocModal('passport_extension_study_visa')">Passport Extension Study Visa</div>
            <div class="noc-gallery-item" onclick="openNocModal('last_visa_extension_study_visa')">Last Visa Extension Study Visa</div>
            <div class="noc-gallery-item" onclick="openNocModal('supporting_docs_extension_study_visa')">Supporting Docs Extension Study Visa</div>
            <div class="noc-gallery-item" onclick="openNocModal('passport_account_opening')">Passport Account Opening</div>
            <div class="noc-gallery-item" onclick="openNocModal('last_visa_account_opening')">Last Visa Account Opening</div>
            <div class="noc-gallery-item" onclick="openNocModal('supporting_docs_account_opening')">Supporting Docs Account Opening</div>
            <div class="noc-gallery-item" onclick="openNocModal('certificate_school_equivalence')">Certificate School Equivalence</div>
            <div class="noc-gallery-item" onclick="openNocModal('admission_letter_equivalence')">Admission Letter Equivalence</div>
            <div class="noc-gallery-item" onclick="openNocModal('supporting_docs_equivalence')">Supporting Docs Equivalence</div>
            <div class="noc-gallery-item" onclick="openNocModal('supporting_docs_other_purposes')">Supporting Docs Other Purposes</div>
            <div class="noc-gallery-item" onclick="openNocModal('degree_authorized_letter')">Degree Authorized Letter</div>
            <div class="noc-gallery-item" onclick="openNocModal('passport_authorized_letter')">Passport Authorized Letter</div>
            <div class="noc-gallery-item" onclick="openNocModal('supporting_docs_authorized_letter')">Supporting Docs Authorized Letter</div>
        </div>

        <!-- Modal structure for NOC documents -->
        <div id="noc-modal" class="noc-modal-overlay">
            <span class="noc-close-button" onclick="closeNocModal()">&times;</span>
            <div class="noc-modal-content" style="background-color:none !important;">
                <div class="noc-image-container">
                    <img id="nocModalImage" class="noc-modal-image" src="" alt="Document Image">
                </div>
            </div>
            <!-- Zoom controls -->
            <div class="noc-zoom-controls">
                <span class="noc-control-button" onclick="nocZoomIn()">
                    <i class="fas fa-search-plus"></i> Zoom In
                </span>
                <span class="noc-control-button" onclick="nocZoomOut()">
                    <i class="fas fa-search-minus"></i> Zoom Out
                </span>
                <span class="noc-control-button" onclick="nocDownloadImage()">
                    <i class="fas fa-download"></i> Download
                </span>
            </div>
        </div>

        <?php
        } else {
            // If student not found, display an error message
        ?>
            <div class="tab-content">
                <div class="tab-pane fade show active" id="personal-info" role="tabpanel" aria-labelledby="personal-info-tab">
                    <div class="content-page">
                        <div class="container-fluid">
                            <div class="alert alert-danger" role="alert">
                                <strong>Empty!</strong> You didn't fill the NOC form yet. Fill <a href="noc-documents.php"> clicking here</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
        ?>
</div>

        <div class="tab-pane fade" id="letters" role="tabpanel" aria-labelledby="letters-tab">
          Content for Letters
        </div>
        
      </div>
    </div>
  </div>
</div>



        </div>
    </div>
    
   <!-- jQuery and Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

 

<!-- JavaScript to handle NOC modal opening, closing, zooming, and downloading -->
<script>
    // Mapping of NOC documents
    const nocDocuments = {
        passport_extension_study_visa: "<?php echo '../utilities/' . htmlspecialchars($document['passport_extension_study_visa']); ?>",
        last_visa_extension_study_visa: "<?php echo '../utilities/' . htmlspecialchars($document['last_visa_extension_study_visa']); ?>",
        supporting_docs_extension_study_visa: "<?php echo '../utilities/' . htmlspecialchars($document['supporting_docs_extension_study_visa']); ?>",
        passport_account_opening: "<?php echo '../utilities/' . htmlspecialchars($document['passport_account_opening']); ?>",
        last_visa_account_opening: "<?php echo '../utilities/' . htmlspecialchars($document['last_visa_account_opening']); ?>",
        supporting_docs_account_opening: "<?php echo '../utilities/' . htmlspecialchars($document['supporting_docs_account_opening']); ?>",
        certificate_school_equivalence: "<?php echo '../utilities/' . htmlspecialchars($document['certificate_school_equivalence']); ?>",
        admission_letter_equivalence: "<?php echo '../utilities/' . htmlspecialchars($document['admission_letter_equivalence']); ?>",
        supporting_docs_equivalence: "<?php echo '../utilities/' . htmlspecialchars($document['supporting_docs_equivalence']); ?>",
        supporting_docs_other_purposes: "<?php echo '../utilities/' . htmlspecialchars($document['supporting_docs_other_purposes']); ?>",
        degree_authorized_letter: "<?php echo '../utilities/' . htmlspecialchars($document['degree_authorized_letter']); ?>",
        passport_authorized_letter: "<?php echo '../utilities/' . htmlspecialchars($document['passport_authorized_letter']); ?>",
        supporting_docs_authorized_letter: "<?php echo '../utilities/' . htmlspecialchars($document['supporting_docs_authorized_letter']); ?>"
    };

    let zoomLevel = 1; // Variable to keep track of zoom level

    function openNocModal(documentKey) {
        const imageUrl = nocDocuments[documentKey];
        const modal = document.getElementById("noc-modal");
        const modalImage = document.getElementById("nocModalImage");

        modalImage.src = imageUrl; // Set the image source
        zoomLevel = 1; // Reset zoom level
        modalImage.style.transform = "scale(1)"; // Reset zoom on open

        modal.style.display = "flex"; // Show the modal
    }

    function closeNocModal() {
        const modal = document.getElementById("noc-modal");
        modal.style.display = "none"; // Hide the modal
    }

    function nocZoomIn() {
        const modalImage = document.getElementById("nocModalImage");
        zoomLevel += 0.1; // Increment zoom level
        modalImage.style.transform = "scale(" + zoomLevel + ")"; // Apply zoom
    }

    function nocZoomOut() {
        const modalImage = document.getElementById("nocModalImage");
        zoomLevel = Math.max(1, zoomLevel - 0.1); // Decrement zoom level, not below 1
        modalImage.style.transform = "scale(" + zoomLevel + ")"; // Apply zoom
    }

    function nocDownloadImage() {
        const modalImage = document.getElementById("nocModalImage");
        const downloadLink = document.createElement('a');
        downloadLink.href = modalImage.src; // Set download link to image source
        downloadLink.download = ""; // Trigger download
        document.body.appendChild(downloadLink);
        downloadLink.click(); // Programmatically click the link
        document.body.removeChild(downloadLink); // Remove the link after download
    }
</script>

         


<?php include 'inc/footer.php';?>