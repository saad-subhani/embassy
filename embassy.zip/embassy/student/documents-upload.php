<?php include 'inc/sidebar.php'; ?>

<div class="page-wrapper pagehead">
    <div class="content">
        <div class="row">
            <div class="col-sm-12">
                <div class="container-fluid mt-2">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h2 class="mb-4 text-center">Student Visa Document Submission Form</h2>

                            <form id="studentVisaForm" enctype="multipart/form-data" novalidate method="POST">

                                <!-- Document Uploads Section -->
                                <div class="card mb-4">
                                    <div class="card-body">
                                        <h5 class="mb-3">Document Uploads</h5>

                                        <!-- File Upload Section -->
                                        <div class="form-group mb-3">
                                            <label for="visaApplication">Upload Visa Application</label>
                                            <input type="file" class="form-control" id="visaApplication" name="visaApplication" accept=".pdf, jpg, .jpeg, .png">
                                        </div>

                                        <div class="form-group mb-3">
                                            <label for="visaFeeReceipt">Upload Visa Fee Receipt</label>
                                            <input type="file" class="form-control" id="visaFeeReceipt" name="visaFeeReceipt" accept=".pdf, .jpg, .jpeg">
                                        </div>

                                        <div class="form-group mb-3">
                                            <label for="passportCopy">Upload Passport Photocopy</label>
                                            <input type="file" class="form-control" id="passportCopy" name="passportCopy" accept=".pdf, .jpg, .jpeg">
                                        </div>

                                        <div class="form-group mb-3">
                                            <label for="photo">Upload Your Photo</label>
                                            <input type="file" class="form-control" id="photo" name="photo" accept=".jpg, .jpeg, .png">
                                        </div>

                                        <!-- Verification Letter -->
                                        <h5 class="mb-3">Verification Letter from University (Before Attestations)</h5>

                                        <div class="form-group mb-3">
                                            <label for="verificationDegree" class="form-label">Upload Degree</label>
                                            <input type="file" class="form-control" id="verificationDegree" name="verificationDegree">
                                        </div>

                                        <div class="form-group mb-3">
                                            <label for="verificationTranscript" class="form-label">Upload Transcript</label>
                                            <input type="file" class="form-control" id="verificationTranscript" name="verificationTranscript">
                                        </div>

                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary btn-lg">Submit Application</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- SweetAlert2 Library -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Include Bootstrap 5 -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- FontAwesome (for icons) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>

<script>
// Handle form submission with AJAX
document.getElementById('studentVisaForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    // Create FormData object to send data
    var formData = new FormData(this);

    // AJAX Request
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '../utilities/save-documents.php', true);

    // Handle success/failure of the request
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Parse the JSON response from server (assuming it's JSON formatted)
            var response = JSON.parse(xhr.responseText);
            
            if (response.success) {
                // Show success alert using SweetAlert2
                Swal.fire({
                    title: 'Success!',
                    text: response.message,
                    icon: 'success',
                    confirmButtonText: 'OK'
                });
            } else {
                // Show error alert using SweetAlert2
                Swal.fire({
                    title: 'Error!',
                    text: response.message,
                    icon: 'error',
                    confirmButtonText: 'Try Again'
                });
            }
        } else {
            // Handle other errors (e.g., server not responding)
            Swal.fire({
                title: 'Error!',
                text: 'Something went wrong. Please try again.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        }
    };

    // Send AJAX request
    xhr.send(formData);
});
</script>

<?php include 'inc/footer.php'; ?>
