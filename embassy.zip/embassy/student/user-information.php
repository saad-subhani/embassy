<?php
include 'inc/sidebar.php';

// Assume user_id is retrieved from the session or request
$user_id = $_SESSION['user_id']; // or $_GET['user_id'] if passing via GET
$user_info = null;

include'../utilities/conn.php';

// Check if user information exists
$sql = "SELECT * FROM user_information WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user_info = $result->fetch_assoc();
}

$stmt->close();
$conn->close();
?>

<div class="page-wrapper pagehead">
    <div class="content">
        <div class="container-fluid mt-2">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h2 class="mb-4 text-center">Student Visa Document Submission Form</h2>

                    <form id="studentVisaForm" enctype="multipart/form-data" novalidate>
                        <!-- Personal Information Section -->
                        <div class="mb-4">
                            <h4>Personal Information</h4>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label for="fullName" class="form-label">Full Name</label>
                                    <input type="text" class="form-control" id="fullName" name="fullName" 
                                           placeholder="Enter your full name" required
                                           value="<?php echo $user_info ? htmlspecialchars($user_info['full_name']) : ''; ?>"
                                           <?php echo $user_info ? 'readonly' : ''; ?>>
                                </div>
                                <div class="col-md-4">
                                    <label for="fatherName" class="form-label">Father's Name</label>
                                    <input type="text" class="form-control" id="fatherName" name="fatherName" 
                                           placeholder="Enter father's name" required
                                           value="<?php echo $user_info ? htmlspecialchars($user_info['father_name']) : ''; ?>"
                                           <?php echo $user_info ? 'readonly' : ''; ?>>
                                </div>
                                <div class="col-md-4">
                                    <label for="dob" class="form-label">Date of Birth</label>
                                    <input type="date" class="form-control" id="dob" name="dob" required
                                           value="<?php echo $user_info ? htmlspecialchars($user_info['dob']) : ''; ?>"
                                           <?php echo $user_info ? 'readonly' : ''; ?>>
                                </div>
                            </div>
                        </div>

                        <!-- Contact Information Section -->
                        <div class="mb-4">
                            <h4>Contact Information</h4>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           placeholder="Enter your email" required
                                           value="<?php echo $user_info ? htmlspecialchars($user_info['Email']) : ''; ?>"
                                           <?php echo $user_info ? 'readonly' : ''; ?>>
                                </div>
                                <div class="col-md-4">
                                    <label for="contactNumber" class="form-label">Contact Number</label>
                                    <input type="tel" class="form-control" id="contactNumber" name="contactNumber" 
                                           placeholder="Enter your contact number" required
                                           value="<?php echo $user_info ? htmlspecialchars($user_info['number']) : ''; ?>"
                                           <?php echo $user_info ? 'readonly' : ''; ?>>
                                </div>
                                <div class="col-md-4">
                                    <label for="personalPicture" class="form-label">Personal Picture</label>
                                    <input type="file" class="form-control" id="personalPicture" name="personalPicture"
                                           <?php echo $user_info ? 'disabled' : 'required'; ?>>
                                    <?php if ($user_info && $user_info['personal_picture']): ?>
                                        <p>Current Picture: <img src="../utilities/uploads/<?php echo htmlspecialchars($user_info['personal_picture']); ?>" alt="Personal Picture" width="100"></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Address Information Section -->
                        <div class="mb-4">
                            <h4>Address Information</h4>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="addressPalestine" class="form-label">Address in Palestine</label>
                                    <input type="text" class="form-control" id="addressPalestine" name="addressPalestine" 
                                           placeholder="Enter your address in Palestine" required
                                           value="<?php echo $user_info ? htmlspecialchars($user_info['address_palestine']) : ''; ?>"
                                           <?php echo $user_info ? 'readonly' : ''; ?>>
                                </div>
                                <div class="col-md-6">
                                    <label for="addressPakistan" class="form-label">Address in Pakistan</label>
                                    <input type="text" class="form-control" id="addressPakistan" name="addressPakistan" 
                                           placeholder="Enter your address in Pakistan" required
                                           value="<?php echo $user_info ? htmlspecialchars($user_info['address_pakistan']) : ''; ?>"
                                           <?php echo $user_info ? 'readonly' : ''; ?>>
                                </div>
                            </div>
                        </div>

                        <!-- University Information Section -->
                        <div class="mb-4">
                            <h4>University Information</h4>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label for="universityName" class="form-label">University Name (In Palestine)</label>
                                    <input type="text" class="form-control" id="universityName" name="universityName" 
                                           placeholder="Enter university name" required
                                           value="<?php echo $user_info ? htmlspecialchars($user_info['university_name']) : ''; ?>"
                                           <?php echo $user_info ? 'readonly' : ''; ?>>
                                </div>
                                <div class="col-md-4">
                                    <label for="major" class="form-label">Major/Program of Study</label>
                                    <input type="text" class="form-control" id="major" name="major" 
                                           placeholder="Enter program of study" required
                                           value="<?php echo $user_info ? htmlspecialchars($user_info['major']) : ''; ?>"
                                           <?php echo $user_info ? 'readonly' : ''; ?>>
                                </div>
                                <div class="col-md-4">
                                    <label for="studentId" class="form-label">Student ID</label>
                                    <input type="text" class="form-control" id="studentId" name="studentId" 
                                           placeholder="Enter student ID" required
                                           value="<?php echo $user_info ? htmlspecialchars($user_info['student_id']) : ''; ?>"
                                           <?php echo $user_info ? 'readonly' : ''; ?>>
                                </div>
                            </div>
                        </div>

                        <!-- Visa Information Section -->
                        <div class="mb-4">
                            <h4>Visa Information</h4>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="visaStartDate" class="form-label">Visa Start Date</label>
                                    <input type="date" class="form-control" id="visaStartDate" name="visaStartDate" required
                                           value="<?php echo $user_info ? htmlspecialchars($user_info['visa_start_date']) : ''; ?>"
                                           <?php echo $user_info ? 'readonly' : ''; ?>>
                                </div>
                                <div class="col-md-6">
                                    <label for="visaExpireDate" class="form-label">Visa Expiry Date</label>
                                    <input type="date" class="form-control" id="visaExpireDate" name="visaExpireDate" required
                                           value="<?php echo $user_info ? htmlspecialchars($user_info['visa_expire_date']) : ''; ?>"
                                           <?php echo $user_info ? 'readonly' : ''; ?>>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="text-center">
                            <?php if (!$user_info): // Show submit button only if no existing data ?>
                                <button type="submit" class="btn btn-primary btn-lg">Submit Information</button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- SweetAlert2 Library -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Include Bootstrap 5 -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Handle form submission with AJAX
    document.getElementById('studentVisaForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent default form submission

        // Create FormData object to send data
        var formData = new FormData(this);

        // AJAX Request
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '../utilities/save-user-information.php', true);

        // Handle success/failure of the request
        xhr.onload = function() {
            if (xhr.status === 200) {
                // Parse the JSON response from the server (assuming it's JSON formatted)
                var response = JSON.parse(xhr.responseText);
                
                if (response.success) {
                    // Show success alert using SweetAlert2
                    Swal.fire({
                        title: 'Success!',
                        text: response.message,
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        // Reset the form only on success
                        document.getElementById('studentVisaForm').reset();
                    });
                } else {
                    // Show error alert using SweetAlert2
                    Swal.fire({
                        title: 'Error!',
                        text: response.message,
                        icon: 'error',
                        confirmButtonText: 'Try Again'
                    });
                }
            } else {
                // Handle other errors (e.g., server not responding)
                Swal.fire({
                    title: 'Error!',
                    text: 'Something went wrong. Please try again.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            }
        };

        // Send AJAX request
        xhr.send(formData);
    });
</script>


<?php include 'inc/footer.php'; ?>
