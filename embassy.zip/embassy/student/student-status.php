 <?php include 'inc/sidebar.php'; ?>
 <div class="page-wrapper">
  <div class="content">
<?php
// Start the session to access session variables

// Check if the user is logged in by checking if 'user_id' is set in the session
if (!isset($_SESSION['user_id'])) {
    echo "<script>console.log('You are not logged in. Please log in to view details.');</script>";
    exit();
}

$user_id = $_SESSION['user_id']; // Get the user_id from the session

// Database connection
include '../utilities/conn.php';

// Fetch user status based on the session user_id
$sql = "SELECT status FROM user_information WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id); // 'i' indicates the parameter is an integer (user_id)
$stmt->execute();
$result = $stmt->get_result();

// Check if user details exist for the logged-in user
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc(); // Fetch the user details as an associative array
    $status = $user['status']; // Get the user's application status

    // Log the status to the console
    echo "<script>
            console.log('User ID: " . htmlspecialchars($user_id) . "');
            console.log('Application Status: " . htmlspecialchars($status) . "');
          </script>";

    // Close connection
    $stmt->close();
    $conn->close();
    
    // Display the appropriate message based on the status
    if ($status == 'Pending') {
        echo "<div class='wrapper'>
                <div class='container'>
                    <div class='row no-gutters height-self-center'>
                        <div class='col-sm-12 text-center align-self-center'>
                            <div class='iq-error position-relative'>
                                <img src='../assets/img/pending.jpg' class='img-fluid iq-error-img mb-0' alt='' width='350'>
                                <h2 class='mb-0'>Your Application Request is still Pending</h2>
                                <p>We Appreciate Your Patience</p>
                                <a class='btn btn-primary d-inline-flex align-items-center mt-3' href='student-history.php'>
                                    <i class='ri-home-4-line mr-2'></i>View Complete History
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
              </div>";
    } elseif ($status == 'Approved') {
        echo "<div class='wrapper'>
                <div class='container'>
                    <div class='row no-gutters height-self-center'>
                        <div class='col-sm-12 text-center align-self-center'>
                            <div class='iq-error position-relative'>
                                <img src='../assets/img/approved.jpeg' class='img-fluid iq-error-img mb-0' alt='' width='350'>
                                <h2 class='mb-0'>Your Application Request is Approved</h2>
                                <p>We Congratulate You</p>
                                <a class='btn btn-primary d-inline-flex align-items-center mt-3' href='student-history.php'>
                                    <i class='ri-home-4-line mr-2'></i>View Complete History
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
              </div>";
    } elseif ($status == 'Rejected') {
        echo "<div class='wrapper'>
                <div class='container'>
                    <div class='row no-gutters height-self-center'>
                        <div class='col-sm-12 text-center align-self-center'>
                            <div class='iq-error position-relative'>
                                <img src='../assets/img/rejected.jpg' class='img-fluid iq-error-img mb-0' alt='' width='350'>
                                <h2 class='mb-0'>Your Application Request is Rejected</h2>
                                <p>We Appreciate You Applying</p>
                                <a class='btn btn-primary d-inline-flex align-items-center mt-3' href='student-history.php'>
                                    <i class='ri-home-4-line mr-2'></i>View Complete History
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
              </div>";
    }
} else {
    echo "<div class='wrapper'>
    <div class='container'>
        <div class='row no-gutters height-self-center'>
            <div class='col-sm-12 text-center align-self-center'>
                <div class='iq-error position-relative'>
                    <img src='../assets/img/application.jpg' class='img-fluid iq-error-img mb-0' alt='' width='350'>
                    <h2 class='mb-0'>Please submit your documents to view your status</h2>
                    <p>Thank you for your co-operation. We Appreciate it!</p>
                    <a class='btn btn-primary d-inline-flex align-items-center mt-3' href='student-form.php'>
                        <i class='ri-home-4-line mr-2'></i>Apply Here
                    </a>
                </div>
            </div>
        </div>
    </div>
  </div>";
    exit();
}
?>
  </div>
  </div>
  <?php include 'inc/footer.php'; ?>