<?php
// Start the session
session_start();

// Include the database connection
include '../utilities/conn.php';

if (isset($_SESSION['user_id'])) {
    // Store the user ID from the session
    $user_id = $_SESSION['user_id'];

    // Prepare the SQL query to fetch the signup date from the users table
    $query = "SELECT created_at FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch the signup date
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $formatted_date = date("F j, Y", strtotime($user['created_at']));
    } else {
        $formatted_date = "Unknown date";
    }

    $stmt->close();

    // Prepare the SQL query to check if user information exists in the user_information table
    $query_info = "SELECT created_at, status, status_change_date FROM user_information WHERE user_id = ?";
    $stmt_info = $conn->prepare($query_info);
    $stmt_info->bind_param("i", $user_id);
    $stmt_info->execute();
    $result_info = $stmt_info->get_result();

    // Check if the user's documents were submitted
    if ($result_info->num_rows > 0) {
        $user_info = $result_info->fetch_assoc();
        $document_date = date("F j, Y", strtotime($user_info['created_at']));
        $document_message = "You submitted your documents on <strong>" . htmlspecialchars($document_date) . "</strong>.";
        $documents_submitted = true; // Flag to show the document card

        // Fetch the status and status_change_date
        $status = $user_info['status'];
        $status_change_date = $user_info['status_change_date'];
        if ($status_change_date) {
            $formatted_status_date = date("F j, Y", strtotime($status_change_date));
        } else {
            $formatted_status_date = null;
        }
    } else {
        $documents_submitted = false; // Flag to hide the document card
    }

    // Prepare the SQL query to fetch applications for the logged-in user
    $query_applications = "SELECT created_at, application_for FROM applications WHERE user_id = ?";
    $stmt_applications = $conn->prepare($query_applications);
    $stmt_applications->bind_param("i", $user_id);
    $stmt_applications->execute();
    $result_applications = $stmt_applications->get_result();

    // Store applications data for display
    $applications = [];
    while ($row = $result_applications->fetch_assoc()) {
        $applications[] = $row; // Store each application row
    }

    $stmt_applications->close();
    $conn->close();
} else {
    header("Location: login.php");
    exit();
}
?>

<?php include 'inc/sidebar.php'; ?>

<div class="page-wrapper">
    <div class="content">
        <div class="container">
            <!-- First Card: Account Signup Date -->
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card mt-4">
                        <div class="card-header">
                            <h4 class="text-center">Account Details</h4>
                        </div>
                        <div class="card-body text-center">
                            <p>You signed up on <strong><?php echo htmlspecialchars($formatted_date); ?></strong></p>
                            <a class="btn btn-primary" href="index.php">Go to Dashboard</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Show Second Card only if documents have been submitted -->
            <?php if ($documents_submitted): ?>
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="card mt-4">
                            <div class="card-header">
                                <h4 class="text-center">Document Submission</h4>
                            </div>
                            <div class="card-body text-center">
                                <p><?php echo $document_message; ?></p>
                                <a class="btn btn-primary" href="student-profile.php">View Documents</a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- New Card for Document Review Status -->
                <?php if ($status_change_date): ?>
                    <div class="row justify-content-center">
                        <div class="col-md-6">
                            <div class="card mt-4">
                                <div class="card-header">
                                    <h4 class="text-center">Document Review Status</h4>
                                </div>
                                <div class="card-body text-center">
                                    <?php
                                    // Check the status and display the appropriate message
                                    if ($status == 'Rejected') {
                                        echo "After review, your documents were rejected on <strong>" . htmlspecialchars($formatted_status_date) . "</strong>.";
                                    } elseif ($status == 'Approved') {
                                        echo "After review, your documents were approved on <strong>" . htmlspecialchars($formatted_status_date) . "</strong>.";
                                    } elseif ($status == 'Pending') {
                                        echo "Your documents are in review as of <strong>" . htmlspecialchars($formatted_status_date) . "</strong>.";
                                    } else {
                                        echo "Unknown status.";
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <!-- Loop through applications to create cards -->
            <?php if (!empty($applications)): ?>
                <?php foreach ($applications as $row): ?>
                    <div class="row justify-content-center">
                        <div class="col-md-6">
                            <div class="card mt-4">
                                <div class="card-header">
                                    <h4 class="text-center">Application Details</h4>
                                </div>
                                <div class="card-body text-center">
                                    <p>You submitted an application for <strong><?php echo htmlspecialchars($row['application_for']); ?></strong> on <strong><?php echo date("F j, Y", strtotime($row['created_at'])); ?></strong>.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php include 'inc/footer.php'; ?>
