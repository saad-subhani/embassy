<?php include 'inc/sidebar.php'; ?>

<div class="page-wrapper pagehead">
<div class="content">
<!-- <div class="page-header">
<div class="row">
<div class="col-sm-12">
<h3 class="page-title">Blank Page</h3>
<ul class="breadcrumb">
<li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
<li class="breadcrumb-item active">Blank Page</li>
</ul>
</div>
</div>
</div> -->
<div class="row">
<div class="col-sm-12">
    <div class="container-fluid mt-5">
        <div class="card shadow-sm">
            <div class="card-body">
                <h2 class="mb-4 text-center">Student Visa Document Submission Form</h2>
    
                <form id="studentVisaForm" enctype="multipart/form-data" novalidate method="POST" action="../utilities/save-form.php"> 



                <!-- SECTION 1 -->
                    <!-- Personal Information Section -->
                   <!-- Single Card Structure -->
<div class="card mb-3" id="one">
    <div class="card-header">
        <h4 class="mb-0">
            <a href="#" class="text-decoration-none" data-bs-toggle="collapse" data-bs-target="#collapseInfo" aria-expanded="true" aria-controls="collapseInfo">
                Click to View Information
            </a>
        </h4>
    </div>
    <div id="collapseInfo" class="collapse">
    <div class="card-body">
    <!-- Personal Information Section -->
    <h5>Personal Information</h5>
    <div class="row">
        <div class="form-group col-md-4">
            <label for="fullName">Full Name</label>
            <input type="text" class="form-control" id="fullName" name="fullName" placeholder="Enter your full name">
        </div>
        <div class="form-group col-md-4">
            <label for="fatherName">Father's Name</label>
            <input type="text" class="form-control" id="fatherName" name="fatherName" placeholder="Enter father's name">
        </div>
        <div class="form-group col-md-4">
            <label for="dob">Date of Birth</label>
            <input type="date" class="form-control" id="dob" name="dob">
        </div>
    </div>

    <!-- Contact Information Section -->
    <h5>Contact Information</h5>
    <div class="row">
        <div class="form-group col-md-4">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email">
        </div>
        <div class="form-group col-md-4">
            <label for="contactNumber">Contact Number</label>
            <input type="tel" class="form-control" id="contactNumber" name="contactNumber" placeholder="Enter your contact number">
        </div>
        <div class="form-group col-md-4">
            <label for="personalPicture">Personal Picture</label>
            <input type="file" class="form-control-file" id="personalPicture" name="personalPicture">
        </div>
    </div>

    <!-- Address Information Section -->
    <h5>Address Information</h5>
    <div class="row">
        <div class="form-group col-md-6">
            <label for="addressPalestine">Address in Palestine</label>
            <input type="text" class="form-control" id="addressPalestine" name="addressPalestine" placeholder="Enter your address in Palestine">
        </div>
        <div class="form-group col-md-6">
            <label for="addressPakistan">Address in Pakistan</label>
            <input type="text" class="form-control" id="addressPakistan" name="addressPakistan" placeholder="Enter your address in Pakistan">
        </div>
    </div>

    <!-- University Information Section -->
    <h5>University Information</h5>
    <div class="row">
        <div class="form-group col-md-4">
            <label for="universityName">University Name (In Palestine)</label>
            <input type="text" class="form-control" id="universityName" name="universityName" placeholder="Enter university name">
        </div>
        <div class="form-group col-md-4">
            <label for="major">Major/Program of Study</label>
            <input type="text" class="form-control" id="major" name="major" placeholder="Enter program of study">
        </div>
        <div class="form-group col-md-4">
            <label for="studentId">Student ID</label>
            <input type="text" class="form-control" id="studentId" name="studentId" placeholder="Enter student ID">
        </div>
    </div>

    <!-- Visa Information Section -->
    <h5>Visa Information</h5>
    <div class="row">
        <div class="form-group col-md-6">
            <label for="visaStartDate">Visa Start Date</label>
            <input type="date" class="form-control" id="visaStartDate" name="visaStartDate">
        </div>
        <div class="form-group col-md-6">
            <label for="visaExpireDate">Visa Expiry Date</label>
            <input type="date" class="form-control" id="visaExpireDate" name="visaExpireDate">
        </div>
    </div>

    <!-- Button to Open Next Card -->
    <button type="button" class="btn btn-primary" onclick="openNextCard('collapseInfo', 'collapseDocuments')">Next</button>
</div>

    </div>
</div>


 <!-- SECTION 2 -->
<div class="card mb-3" id="two">
    <div class="card-header">
        <h4 class="mb-0">
            <a href="#" class="text-decoration-none" data-bs-toggle="collapse" data-bs-target="#collapseDocuments" aria-expanded="false" aria-controls="collapseDocuments">
                Click to Upload Documents
            </a>
        </h4>
    </div>
    <div id="collapseDocuments" class="collapse">
        <div class="card-body">
            <!-- File Upload Section -->
            <h5 class="mb-3">Document Uploads</h5>

            <div class="form-group mb-3">
                <label for="visaApplication">Upload Visa Application</label>
                <input type="file" class="form-control" id="visaApplication" name="visaApplication" accept=".pdf">
            </div>

            <div class="form-group mb-3">
                <label for="visaFeeReceipt">Upload Visa Fee Receipt</label>
                <input type="file" class="form-control" id="visaFeeReceipt" name="visaFeeReceipt" accept=".pdf, .jpg, .jpeg">
            </div>

            <div class="form-group mb-3">
                <label for="passportCopy">Upload Passport Photocopy</label>
                <input type="file" class="form-control" id="passportCopy" name="passportCopy" accept=".pdf, .jpg, .jpeg">
            </div>

            <div class="form-group mb-3">
                <label for="photo">Upload Your Photo</label>
                <input type="file" class="form-control" id="photo" name="photo" accept=".jpg, .jpeg, .png">
            </div>

            <!-- Verification Letter -->
            <h5 class="mb-3">Verification Letter from University (Before Attestations)</h5>

            <div class="form-group mb-3">
                <label for="verificationDegree" class="form-label">Upload Degree</label>
                <input type="file" class="form-control" id="verificationDegree" name="verificationDegree">
                <div class="invalid-feedback">Please upload your degree.</div>
            </div>

            <div class="form-group mb-3">
                <label for="verificationTranscript" class="form-label">Upload Transcript</label>
                <input type="file" class="form-control" id="verificationTranscript" name="verificationTranscript">
                <div class="invalid-feedback">Please upload your transcript.</div>
            </div>
        </div>
    </div>
</div>

<!-- SECTION 3 -->
<div class="card mb-3" id="three">
    <div class="card-header">
        <h4 class="mb-0">
            <a href="#" class="text-decoration-none" data-bs-toggle="collapse" data-bs-target="#collapseNOCSection" aria-expanded="false" aria-controls="collapseNOCSection">
                Click to Upload NOC Documents
            </a>
        </h4>
    </div>
    <div id="collapseNOCSection" class="collapse">
        <div class="card-body">

            <!-- NOC for Extension Study Visa -->
            <h5 class="mb-3">NOC for Extension Study Visa</h5>
            <div class="form-group mb-3">
                <label for="extensionStudyVisaPassport">Upload Passport</label>
                <input type="file" class="form-control" id="extensionStudyVisaPassport" name="extensionStudyVisaPassport" >
            </div>
            <div class="form-group mb-3">
                <label for="extensionStudyVisaLastVisa">Upload Last Visa</label>
                <input type="file" class="form-control" id="extensionStudyVisaLastVisa" name="extensionStudyVisaLastVisa" >
            </div>
            <div class="form-group mb-3">
                <label for="extensionStudyVisaDocuments">Upload Supporting Documents</label>
                <input type="file" class="form-control" id="extensionStudyVisaDocuments" name="extensionStudyVisaDocuments[]" multiple >
            </div>

            <!-- NOC for Account Opening Certificate -->
            <h5 class="mb-3">NOC for Account Opening Certificate</h5>
            <div class="form-group mb-3">
                <label for="accountOpeningPassport">Upload Passport</label>
                <input type="file" class="form-control" id="accountOpeningPassport" name="accountOpeningPassport" >
            </div>
            <div class="form-group mb-3">
                <label for="accountOpeningVisa">Upload Last Visa</label>
                <input type="file" class="form-control" id="accountOpeningVisa" name="accountOpeningVisa" >
            </div>
            <div class="form-group mb-3">
                <label for="accountOpeningDocuments">Other Documents 
                    <i class="fas fa-info-circle" data-bs-toggle="tooltip" title="Admission Letter, Bank Statement, etc."></i>
                </label>
                <input type="file" class="form-control" id="accountOpeningDocuments" name="accountOpeningDocuments[]" multiple >
            </div>

            <!-- NOC for Equivalence Certificate -->
            <h5 class="mb-3">NOC for Equivalence Certificate</h5>
            <div class="form-group mb-3">
                <label for="equivalenceCertificateSchool">Upload School or Degree Certificate</label>
                <input type="file" class="form-control" id="equivalenceCertificateSchool" name="equivalenceCertificateSchool" >
            </div>
            <div class="form-group mb-3">
                <label for="equivalenceCertificateAdmission">Upload Admission Letter</label>
                <input type="file" class="form-control" id="equivalenceCertificateAdmission" name="equivalenceCertificateAdmission" >
            </div>
            <div class="form-group mb-3">
                <label for="equivalenceCertificateDocuments">Upload Other Supporting Documents</label>
                <input type="file" class="form-control" id="equivalenceCertificateDocuments" name="equivalenceCertificateDocuments[]" multiple >
            </div>

            <!-- NOC for Other Purposes -->
            <h5 class="mb-3">NOC for Other Purposes (Explain in Arabic)</h5>
            <div class="form-group mb-3">
                <textarea class="form-control" id="otherPurposesArabic" name="otherPurposesArabic" rows="3" placeholder="Explain here in Arabic..."></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="otherPurposesDocuments">Upload Supporting Documents (if any)</label>
                <input type="file" class="form-control" id="otherPurposesDocuments" name="otherPurposesDocuments[]" multiple >
            </div>

            <!-- NOC for Authorized Letter -->
            <h5 class="mb-3">NOC for Authorized Letter (By the Name of Mr (______))</h5>
            <div class="form-group mb-3">
                <label for="authorizedLetterDegree">Upload Degree</label>
                <input type="file" class="form-control" name="authorizedLetterDegree" id="authorizedLetterDegree" >
            </div>
            <div class="form-group mb-3">
                <label for="authorizedLetterPassport">Upload Passport</label>
                <input type="file" class="form-control" name="authorizedLetterPassport" id="authorizedLetterPassport" >
            </div>
            <div class="form-group mb-3">
                <label for="authorizedPersonID">Upload Authorized Person's ID
                    <i class="fas fa-info-circle" data-bs-toggle="tooltip" title="ID or Passport, Written Letter from You, Written Letter from General Union"></i>
                </label>
                <input type="file" class="form-control" name="authorizedPersonID" id="authorizedPersonID" >
            </div>
            <div class="form-group mb-3">
                <label for="authorizedLetterDocuments">Upload Other Documents</label>
                <input type="file" class="form-control" name="authorizedLetterDocuments[]" id="authorizedLetterDocuments" multiple >
            </div>

        </div>
    </div>
</div>


<!-- SECTION 4 -->
<div class="card mb-3" id="four">
    <div class="card-header">
        <h4 class="mb-0">
            <a href="#" class="text-decoration-none" data-bs-toggle="collapse" data-bs-target="#collapseAdditionalInfo" aria-expanded="false" aria-controls="collapseAdditionalInfo">
                Additional Information
            </a>
        </h4>
    </div>
    <div id="collapseAdditionalInfo" class="collapse">
        <div class="card-body">
            <div class="form-group">
                <label for="comments">Comments or Special Requests</label>
                <textarea class="form-control" name="comments" id="comments" rows="4" placeholder="Enter any comments or special requests" style="font-size: 0.9rem;"></textarea>
                <div class="invalid-feedback">Please enter your comments.</div>
            </div>
        </div>
    </div>
</div>
                    <!-- Submit Button -->
                    <button type="submit" class="btn btn-primary btn-block">Submit Application</button>
                </form>
            </div>
        </div>
    </div>
    
</div>
</div>
</div>
</div>
</div>

<script>
function openNextCard(currentCardId, nextCardId) {
    // Close the current card
    var currentCard = document.getElementById(currentCardId);
    var bsCurrentCollapse = new bootstrap.Collapse(currentCard, {
        toggle: false // Don't toggle the current card
    });
    bsCurrentCollapse.hide();

    // Open the next card
    var nextCard = document.getElementById(nextCardId);
    var bsNextCollapse = new bootstrap.Collapse(nextCard, {
        toggle: true // Toggle the next card
    });
}
</script>











<!-- Include Bootstrap 5 -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<?php include 'inc/footer.php'; ?>