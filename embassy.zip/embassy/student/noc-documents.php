<?php include 'inc/sidebar.php'; ?>

<div class="page-wrapper pagehead">
    <div class="content">
        <div class="row">
            <div class="col-sm-12">
                <div class="container-fluid mt-2">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h2 class="mb-2 text-center">Student Visa Document Submission Form</h2>

                            <form id="studentVisaForm" enctype="multipart/form-data" novalidate method="POST"> 
                                
                                <!-- SECTION 3 -->
                                <div class="card mb-2">
                                    <div class="card-header">
                                        <h4 class="mb-0">Upload NOC Documents</h4>
                                    </div>
                                    <div class="card-body">
                                        <!-- NOC for Extension Study Visa -->
                                        <h5 class="mb-3">NOC for Extension Study Visa</h5>
                                        <div class="form-group mb-3">
                                            <label for="extensionStudyVisaPassport">Upload Passport</label>
                                            <input type="file" class="form-control" id="extensionStudyVisaPassport" name="extensionStudyVisaPassport" required>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="extensionStudyVisaLastVisa">Upload Last Visa</label>
                                            <input type="file" class="form-control" id="extensionStudyVisaLastVisa" name="extensionStudyVisaLastVisa" required>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="extensionStudyVisaDocuments">Upload Supporting Documents</label>
                                            <input type="file" class="form-control" id="extensionStudyVisaDocuments" name="extensionStudyVisaDocuments[]" multiple required>
                                        </div>

                                        <!-- NOC for Account Opening Certificate -->
                                        <h5 class="mb-3">NOC for Account Opening Certificate</h5>
                                        <div class="form-group mb-3">
                                            <label for="accountOpeningPassport">Upload Passport</label>
                                            <input type="file" class="form-control" id="accountOpeningPassport" name="accountOpeningPassport" required>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="accountOpeningVisa">Upload Last Visa</label>
                                            <input type="file" class="form-control" id="accountOpeningVisa" name="accountOpeningVisa" required>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="accountOpeningDocuments">Other Documents <i class="fas fa-info-circle" data-bs-toggle="tooltip" title="Admission Letter, Bank Statement, etc."></i></label>
                                            <input type="file" class="form-control" id="accountOpeningDocuments" name="accountOpeningDocuments[]" multiple>
                                        </div>

                                        <!-- NOC for Equivalence Certificate -->
                                        <h5 class="mb-3">NOC for Equivalence Certificate</h5>
                                        <div class="form-group mb-3">
                                            <label for="equivalenceCertificateSchool">Upload School or Degree Certificate</label>
                                            <input type="file" class="form-control" id="equivalenceCertificateSchool" name="equivalenceCertificateSchool" required>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="equivalenceCertificateAdmission">Upload Admission Letter</label>
                                            <input type="file" class="form-control" id="equivalenceCertificateAdmission" name="equivalenceCertificateAdmission" required>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="equivalenceCertificateDocuments">Upload Other Supporting Documents</label>
                                            <input type="file" class="form-control" id="equivalenceCertificateDocuments" name="equivalenceCertificateDocuments[]" multiple required>
                                        </div>

                                        <!-- NOC for Other Purposes -->
                                        <h5 class="mb-3">NOC for Other Purposes (Explain in Arabic)</h5>
                                        <div class="form-group mb-3">
                                            <textarea class="form-control" id="otherPurposesArabic" name="otherPurposesArabic" rows="3" placeholder="Explain here in Arabic..."></textarea>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="otherPurposesDocuments">Upload Supporting Documents (if any)</label>
                                            <input type="file" class="form-control" id="otherPurposesDocuments" name="otherPurposesDocuments[]" multiple>
                                        </div>

                                        <!-- NOC for Authorized Letter -->
                                        <h5 class="mb-3">NOC for Authorized Letter (By the Name of Mr (______))</h5>
                                        <div class="form-group mb-3">
                                            <label for="authorizedLetterDegree">Upload Degree</label>
                                            <input type="file" class="form-control" name="authorizedLetterDegree" id="authorizedLetterDegree" required>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="authorizedLetterPassport">Upload Passport</label>
                                            <input type="file" class="form-control" name="authorizedLetterPassport" id="authorizedLetterPassport" required>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="authorizedPersonID">Upload Authorized Person's ID <i class="fas fa-info-circle" data-bs-toggle="tooltip" title="ID or Passport, Written Letter from You, Written Letter from General Union"></i></label>
                                            <input type="file" class="form-control" name="authorizedPersonID" id="authorizedPersonID" required>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="authorizedLetterDocuments">Upload Other Documents</label>
                                            <input type="file" class="form-control" name="authorizedLetterDocuments[]" id="authorizedLetterDocuments" multiple>
                                        </div>
                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <button type="submit" class="btn btn-primary btn-block">Submit Application</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Include Bootstrap 5 -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- SweetAlert2 Library -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
document.getElementById('studentVisaForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission
    console.log("Form submitted"); // Log submission

    // Create FormData object to send data
    var formData = new FormData(this);
    console.log("FormData created", formData); // Log FormData

    // AJAX Request
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '../utilities/save-noc.php', true);

    // Handle success/failure of the request
    xhr.onload = function() {
        if (xhr.status === 200) {
            console.log("Response received", xhr.responseText); // Log response
            // Parse the JSON response from server
            var response = JSON.parse(xhr.responseText);
            
            if (response.success) {
                // Show success alert using SweetAlert2
                Swal.fire({
                    title: 'Success!',
                    text: response.message,
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(() => {
                    // Optionally, redirect or reset the form
                    document.getElementById('studentVisaForm').reset();
                });
            } else {
                // Show error alert using SweetAlert2
                Swal.fire({
                    title: 'Error!',
                    text: response.message,
                    icon: 'error',
                    confirmButtonText: 'Try Again'
                });
            }
        } else {
            // Handle other errors (e.g., server not responding)
            Swal.fire({
                title: 'Error!',
                text: 'Something went wrong. Please try again.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        }
    };

    // Send AJAX request
    xhr.send(formData);
});

</script>

<?php include 'inc/footer.php'; ?>
